import { describe, expect, it } from "vitest";
import { buildRoadmap, defaultUserSkills, getRole, roles } from "@shared/skillpath";
import { createHeuristicRole, updateRoleRequirements } from "@shared/customRole";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const publicContext = (): TrpcContext => ({
  user: null,
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("custom roles and changing requirements", () => {
  it("returns a non-empty role through the public custom-role procedure without an AI key", async () => {
    const caller = appRouter.createCaller(publicContext());
    const result = await caller.skillpath.customRole({ title: "Blockchain Product Strategist" });
    expect(result.role.id).toMatch(/^custom-/);
    expect(result.role.requiredSkills.length).toBeGreaterThanOrEqual(8);
    expect(result.role.requiredSkills.every((requirement) => requirement.skillId)).toBe(true);
  });

  it("returns a non-empty custom role from the offline heuristic", () => {
    const role = createHeuristicRole("Climate Data Lead");
    expect(role.id).toMatch(/^custom-/);
    expect(role.requiredSkills.length).toBeGreaterThanOrEqual(8);
    expect(role.requiredSkills.every((requirement) => requirement.skillId)).toBe(true);
  });

  it("changes an affected user's roadmap when requirements are edited", () => {
    const role = getRole("frontend-developer");
    const before = buildRoadmap(role.id, defaultUserSkills);
    const original = role.requiredSkills.map((requirement) => ({ ...requirement }));
    const first = original[0]!;
    updateRoleRequirements(role.id, [{ ...first, minLevel: Math.min(5, first.minLevel + 1) }, ...original.slice(1)]);
    const after = buildRoadmap(role.id, defaultUserSkills);
    expect(after[0]?.priorityScore).toBeGreaterThanOrEqual(before[0]?.priorityScore ?? 0);
    expect(after.some((item) => item.skillId === first.skillId)).toBe(true);
    updateRoleRequirements(role.id, original);
  });

  it("keeps custom roles in the preset role catalog for subsequent loads", () => {
    const role = createHeuristicRole("Climate Data Lead");
    expect(roles.some((candidate) => candidate.id === role.id)).toBe(true);
  });
});
