import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import {
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronRight,
  Circle,
  CircleDot,
  Clock3,
  Code2,
  Compass,
  Database,
  FileText,
  Github,
  Layers,
  Lightbulb,
  ListChecks,
  Menu,
  MoreHorizontal,
  Network,
  Palette,
  Radar,
  Rocket,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  UserRound,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { RadarChart, PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar as RechartsRadar, ResponsiveContainer } from "recharts";
import { trpc } from "@/lib/trpc";
import {
  defaultProfile,
  defaultUserSkills,
  educationOptions,
  experienceOptions,
  interestOptions,
  type GapItem,
  type LearningResource,
  type Profile,
  type RoadmapItem,
  type RoadmapStatus,
  type Role,
} from "@shared/skillpath";

const navItems = [
  { id: "overview", label: "Overview", icon: LayoutDashboardIcon },
  { id: "role", label: "Explore roles", icon: Compass },
  { id: "gap", label: "Skill gap", icon: Radar },
  { id: "roadmap", label: "My roadmap", icon: ListChecks },
  { id: "progress", label: "Progress", icon: TrendingUp },
  { id: "profile", label: "Profile", icon: UserRound },
] as const;

type ViewId = typeof navItems[number]["id"];

function LayoutDashboardIcon(props: { size?: number; strokeWidth?: number }) {
  return <BarChart3 {...props} />;
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <svg width={compact ? 30 : 34} height={compact ? 30 : 34} viewBox="0 0 34 34" fill="none" aria-hidden="true">
        <defs>
          <linearGradient id="logo-gradient" x1="4" y1="30" x2="31" y2="4" gradientUnits="userSpaceOnUse">
            <stop stopColor="#2563EB" />
            <stop offset="1" stopColor="#14B8A6" />
          </linearGradient>
        </defs>
        <path d="M6 27.5 13.1 20l5.1 3.5L27.8 9" stroke="url(#logo-gradient)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        <path d="m22.2 9 5.6-.4-.6 5.5" stroke="#14B8A6" strokeWidth="2.7" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="6" cy="27.5" r="2.5" fill="#2563EB" />
        <circle cx="13.1" cy="20" r="2.5" fill="#377CE4" />
        <circle cx="18.2" cy="23.5" r="2.5" fill="#168DCE" />
        <circle cx="27.8" cy="9" r="2.5" fill="#14B8A6" />
      </svg>
      {!compact && <span className="font-display text-[18px] font-bold tracking-[-0.03em] text-slate-950">SkillPath <span className="text-teal-600">AI</span></span>}
    </div>
  );
}

function Pill({ children, tone = "blue" }: { children: React.ReactNode; tone?: "blue" | "teal" | "amber" | "slate" | "rose" }) {
  const tones = {
    blue: "bg-blue-50 text-blue-700 ring-blue-100",
    teal: "bg-teal-50 text-teal-700 ring-teal-100",
    amber: "bg-amber-50 text-amber-700 ring-amber-100",
    slate: "bg-slate-100 text-slate-600 ring-slate-200",
    rose: "bg-rose-50 text-rose-700 ring-rose-100",
  };
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold ring-1 ${tones[tone]}`}>{children}</span>;
}

function SectionHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-7 flex items-end justify-between gap-5">
      <div>
        {eyebrow && <p className="mb-2 text-[11px] font-bold uppercase tracking-[0.17em] text-blue-600">{eyebrow}</p>}
        <h1 className="font-display text-[30px] font-bold tracking-[-0.04em] text-slate-950 sm:text-[36px]">{title}</h1>
        {description && <p className="mt-2 max-w-2xl text-[14px] leading-6 text-slate-500">{description}</p>}
      </div>
      {action}
    </div>
  );
}

function ReadinessRing({ value, size = "large" }: { value: number; size?: "large" | "small" }) {
  const dimension = size === "large" ? "h-36 w-36" : "h-20 w-20";
  const inner = size === "large" ? "h-[116px] w-[116px]" : "h-[62px] w-[62px]";
  return (
    <div className={`relative flex ${dimension} shrink-0 items-center justify-center rounded-full`} style={{ background: `conic-gradient(#2563EB ${value * 3.6}deg, #E8EEF8 0deg)` }}>
      <div className={`flex ${inner} flex-col items-center justify-center rounded-full bg-white`}>
        <span className={`${size === "large" ? "text-[29px]" : "text-[17px]"} font-bold tracking-[-0.06em] text-slate-950`}>{Math.round(value)}%</span>
        {size === "large" && <span className="mt-0.5 text-[10px] font-semibold text-slate-400">readiness</span>}
      </div>
    </div>
  );
}

function LevelBars({ current, required }: { current: number; required: number }) {
  return (
    <div className="flex items-center gap-1" aria-label={`Current level ${current} of required ${required}`}>
      {Array.from({ length: 5 }).map((_, index) => <span key={index} className={`h-1.5 w-5 rounded-full ${index < current ? "bg-blue-600" : index < required ? "bg-slate-200" : "bg-slate-100"}`} />)}
    </div>
  );
}

function StatusBadge({ status }: { status: RoadmapStatus }) {
  if (status === "completed") return <Pill tone="teal"><CheckCircle2 size={12} className="mr-1" />Completed</Pill>;
  if (status === "in_progress") return <Pill tone="blue"><CircleDot size={12} className="mr-1" />In progress</Pill>;
  return <Pill tone="slate"><Circle size={11} className="mr-1" />Pending</Pill>;
}

function Landing({ onStart }: { onStart: () => void }) {
  const featureCards = [
    { icon: Target, title: "See the gap", body: "Compare your real skills against the role you want — not a generic checklist." },
    { icon: Lightbulb, title: "Know what to do next", body: "Get a ranked, explainable path made from practical resources and projects." },
    { icon: TrendingUp, title: "Keep moving", body: "Every completed step updates your levels and re-ranks what matters next." },
  ];
  return (
    <div className="min-h-screen overflow-hidden bg-[#f8fbff] text-slate-950">
      <div className="pointer-events-none absolute -left-24 -top-20 h-[420px] w-[420px] rounded-full bg-blue-200/25 blur-3xl" />
      <div className="pointer-events-none absolute right-[-90px] top-[170px] h-[470px] w-[470px] rounded-full bg-teal-200/30 blur-3xl" />
      <header className="relative z-10 mx-auto flex max-w-[1240px] items-center justify-between px-5 py-6 lg:px-8">
        <Logo />
        <div className="flex items-center gap-3">
          <button onClick={onStart} className="hidden text-[13px] font-semibold text-slate-500 transition hover:text-slate-950 sm:block">Try the demo</button>
          <button onClick={onStart} className="pressable rounded-xl bg-slate-950 px-4 py-2.5 text-[13px] font-bold text-white shadow-lg shadow-slate-900/10 transition hover:bg-blue-700">Open workspace <ArrowUpRight size={15} className="ml-1 inline" /></button>
        </div>
      </header>
      <main className="relative z-10 mx-auto max-w-[1240px] px-5 pb-20 pt-10 lg:px-8 lg:pt-20">
        <div className="grid items-center gap-14 lg:grid-cols-[0.91fr_1.09fr] lg:gap-20">
          <div>
            <Pill tone="teal"><Sparkles size={13} className="mr-1.5" /> Your unfair advantage is a plan</Pill>
            <h1 className="mt-6 max-w-[650px] font-display text-[53px] font-bold leading-[0.98] tracking-[-0.07em] text-slate-950 sm:text-[68px]">Make your next career move <span className="gradient-text">obvious.</span></h1>
            <p className="mt-7 max-w-[520px] text-[16px] leading-7 text-slate-500">SkillPath AI turns your current skills into a personalized roadmap for the role you want — with the why behind every step.</p>
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <button onClick={onStart} className="pressable rounded-xl bg-blue-600 px-5 py-3.5 text-[14px] font-bold text-white shadow-xl shadow-blue-600/20 transition hover:bg-blue-700">Build my skill path <ChevronRight size={16} className="ml-1 inline" /></button>
              <div className="flex items-center gap-2 text-[12px] font-medium text-slate-400"><ShieldCheck size={16} className="text-teal-600" /> No generic advice. Just your next best step.</div>
            </div>
            <div className="mt-10 flex items-center gap-6 border-t border-slate-200/80 pt-6 text-[12px] text-slate-400">
              <span><strong className="text-slate-700">60+</strong> skills mapped</span><span><strong className="text-slate-700">10</strong> career paths</span><span><strong className="text-slate-700">100%</strong> explainable</span>
            </div>
          </div>
          <div className="relative">
            <div className="hero-grid absolute inset-[-24px] rounded-[35px] opacity-60" />
            <div className="relative rounded-[28px] border border-white bg-white/90 p-3 shadow-[0_30px_90px_-28px_rgba(37,99,235,0.3)] backdrop-blur">
              <div className="rounded-[20px] border border-slate-100 bg-[#f7faff] p-4 sm:p-6">
                <div className="mb-5 flex items-center justify-between"><div className="flex items-center gap-2"><Logo compact /><span className="text-[12px] font-bold text-slate-700">Workspace preview</span></div><span className="h-2 w-2 rounded-full bg-emerald-400" /></div>
                <div className="grid gap-4 sm:grid-cols-[1fr_0.88fr]">
                  <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm">
                    <div className="flex items-start justify-between"><div><p className="text-[11px] font-semibold uppercase tracking-[0.13em] text-slate-400">Your readiness</p><p className="mt-2 font-display text-[43px] font-bold tracking-[-0.07em] text-slate-950">62<span className="text-[20px] text-slate-400">%</span></p><p className="mt-1 text-[12px] text-emerald-600">↑ 8% this month</p></div><ReadinessRing value={62} size="small" /></div>
                    <div className="mt-7"><div className="mb-2 flex justify-between text-[11px] font-semibold text-slate-400"><span>Skill coverage</span><span>12 / 19</span></div><div className="h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full w-[62%] rounded-full bg-gradient-to-r from-blue-600 to-teal-400" /></div></div>
                    <div className="mt-7 grid grid-cols-2 gap-2"><div className="rounded-xl bg-blue-50 p-3"><p className="text-[11px] font-semibold text-blue-600">Strongest</p><p className="mt-1 text-[12px] font-bold text-slate-800">HTML & CSS</p></div><div className="rounded-xl bg-amber-50 p-3"><p className="text-[11px] font-semibold text-amber-600">Next focus</p><p className="mt-1 text-[12px] font-bold text-slate-800">React testing</p></div></div>
                  </div>
                  <div className="rounded-2xl bg-slate-950 p-5 text-white shadow-lg"><div className="flex items-center justify-between"><p className="text-[11px] font-semibold uppercase tracking-[0.13em] text-slate-400">Next best step</p><Zap size={16} className="text-amber-300" /></div><p className="mt-4 font-display text-[24px] font-bold leading-tight tracking-[-0.05em]">Ship a React portfolio project</p><p className="mt-3 text-[12px] leading-5 text-slate-400">Your gap is 2 levels deep, and this step builds proof you can show.</p><div className="mt-8 flex items-center justify-between border-t border-white/10 pt-4 text-[11px] text-slate-400"><span>8 hours</span><span className="rounded-full bg-white/10 px-2 py-1 text-white">High impact</span></div></div>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-3"><div className="h-12 rounded-xl bg-blue-100/60" /><div className="h-12 rounded-xl bg-teal-100/70" /><div className="h-12 rounded-xl bg-amber-100/60" /></div>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-24 grid gap-4 border-t border-slate-200/80 pt-8 md:grid-cols-3">
          {featureCards.map(({ icon: Icon, title, body }) => <div key={title} className="rounded-2xl p-4 transition hover:bg-white hover:shadow-sm"><Icon size={19} className="text-blue-600" /><h3 className="mt-4 text-[14px] font-bold text-slate-900">{title}</h3><p className="mt-2 max-w-[290px] text-[13px] leading-5 text-slate-500">{body}</p></div>)}
        </div>
      </main>
    </div>
  );
}

function Sidebar({ activeView, setActiveView, mobileOpen, setMobileOpen }: { activeView: ViewId; setActiveView: (id: ViewId) => void; mobileOpen: boolean; setMobileOpen: (value: boolean) => void }) {
  return <aside className={`fixed inset-y-0 left-0 z-40 flex w-[246px] flex-col border-r border-slate-200/80 bg-white px-4 py-5 transition-transform duration-200 lg:static lg:translate-x-0 ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`}>
    <div className="flex items-center justify-between px-2"><Logo /><button onClick={() => setMobileOpen(false)} className="rounded-lg p-1 text-slate-400 lg:hidden"><X size={18} /></button></div>
    <div className="mt-9 px-2"><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">Workspace</p><nav className="mt-3 space-y-1">{navItems.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => { setActiveView(id); setMobileOpen(false); }} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[13px] font-semibold transition ${activeView === id ? "bg-blue-50 text-blue-700" : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"}`}><Icon size={17} strokeWidth={activeView === id ? 2.4 : 1.8} />{label}{id === "roadmap" && <span className="ml-auto rounded-full bg-blue-100 px-1.5 py-0.5 text-[10px] text-blue-700">6</span>}</button>)}</nav></div>
    <div className="mt-auto rounded-2xl bg-gradient-to-br from-slate-950 to-slate-800 p-4 text-white"><div className="flex items-start justify-between"><Sparkles size={17} className="text-teal-300" /><span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Tip</span></div><p className="mt-3 text-[13px] font-semibold leading-5">Small, finished projects beat big, unfinished plans.</p><button onClick={() => setActiveView("roadmap")} className="mt-4 text-[11px] font-bold text-teal-300">View your plan <ArrowUpRight size={13} className="ml-1 inline" /></button></div>
    <div className="mt-5 flex items-center gap-3 border-t border-slate-100 px-2 pt-5"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-teal-400 text-[11px] font-bold text-white">MC</div><div className="min-w-0"><p className="truncate text-[12px] font-bold text-slate-800">Maya Chen</p><p className="text-[10px] text-slate-400">Demo workspace</p></div><MoreHorizontal size={16} className="ml-auto text-slate-300" /></div>
  </aside>;
}

function Topbar({ activeView, onMenu, onExit }: { activeView: ViewId; onMenu: () => void; onExit: () => void }) {
  const label = navItems.find((item) => item.id === activeView)?.label ?? "Overview";
  return <header className="flex h-[73px] items-center justify-between border-b border-slate-200/80 bg-white/90 px-5 backdrop-blur lg:px-8"><div className="flex items-center gap-3"><button onClick={onMenu} className="rounded-lg p-2 text-slate-500 hover:bg-slate-50 lg:hidden"><Menu size={20} /></button><div><p className="text-[10px] font-bold uppercase tracking-[0.17em] text-slate-400">SkillPath AI</p><p className="mt-0.5 text-[14px] font-bold text-slate-900">{label}</p></div></div><div className="flex items-center gap-2 sm:gap-4"><div className="hidden items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-[12px] text-slate-400 sm:flex"><Search size={14} /> <span>Search your skills</span><span className="ml-3 rounded-md bg-white px-1.5 py-0.5 text-[10px] text-slate-300 ring-1 ring-slate-200">⌘ K</span></div><button onClick={onExit} className="text-[12px] font-semibold text-slate-400 transition hover:text-slate-900">Exit preview</button><div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-500 to-teal-400 p-[2px]"><div className="flex h-full w-full items-center justify-center rounded-full bg-white text-[10px] font-bold text-blue-600">MC</div></div></div></header>;
}

function Overview({ dashboard, analysis, setActiveView }: { dashboard: any; analysis: any; setActiveView: (id: ViewId) => void }) {
  const radarData = analysis.items.slice(0, 8).map((item: GapItem) => ({ skill: item.skillName.length > 14 ? `${item.skillName.slice(0, 12)}…` : item.skillName, required: item.requiredLevel, current: item.currentLevel }));
  return <div>
    <SectionHeading eyebrow="Tuesday, September 20" title="Good morning, Maya." description={`Here’s your clearest next step toward becoming a ${dashboard.role.title}.`} action={<button onClick={() => setActiveView("roadmap")} className="pressable hidden rounded-xl bg-slate-950 px-4 py-2.5 text-[12px] font-bold text-white shadow-sm sm:block">Open roadmap <ArrowUpRight size={14} className="ml-1 inline" /></button>} />
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <div className="card-lift rounded-2xl border border-blue-100 bg-gradient-to-br from-blue-600 to-blue-700 p-5 text-white shadow-lg shadow-blue-600/10"><div className="flex items-start justify-between"><div><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-blue-100">Role readiness</p><p className="mt-2 font-display text-[40px] font-bold tracking-[-0.07em]">{Math.round(dashboard.readiness)}<span className="text-[20px] text-blue-200">%</span></p></div><ReadinessRing value={dashboard.readiness} size="small" /></div><p className="mt-4 text-[11px] text-blue-100">+8% since you started your path</p></div>
      <div className="card-lift rounded-2xl border border-slate-200 bg-white p-5"><div className="flex items-center justify-between"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Skills mastered</p><div className="rounded-lg bg-teal-50 p-2 text-teal-600"><CheckCircle2 size={16} /></div></div><p className="mt-4 font-display text-[37px] font-bold tracking-[-0.07em] text-slate-950">{dashboard.masteredCount}<span className="text-[18px] text-slate-300">/{dashboard.totalSkills}</span></p><p className="mt-1 text-[11px] text-slate-400">role skills at target level</p></div>
      <div className="card-lift rounded-2xl border border-slate-200 bg-white p-5"><div className="flex items-center justify-between"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Hours queued</p><div className="rounded-lg bg-amber-50 p-2 text-amber-600"><Clock3 size={16} /></div></div><p className="mt-4 font-display text-[37px] font-bold tracking-[-0.07em] text-slate-950">36<span className="text-[18px] text-slate-300">h</span></p><p className="mt-1 text-[11px] text-slate-400">across your active roadmap</p></div>
      <div className="card-lift rounded-2xl border border-slate-200 bg-white p-5"><div className="flex items-center justify-between"><p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Current streak</p><div className="rounded-lg bg-rose-50 p-2 text-rose-600"><Zap size={16} /></div></div><p className="mt-4 font-display text-[37px] font-bold tracking-[-0.07em] text-slate-950">12<span className="text-[18px] text-slate-300"> days</span></p><p className="mt-1 text-[11px] text-slate-400">keep the momentum alive</p></div>
    </div>
    <div className="mt-5 grid gap-5 xl:grid-cols-[1.18fr_0.82fr]">
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6"><div className="flex items-start justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Skill coverage</p><h2 className="mt-2 font-display text-[20px] font-bold tracking-[-0.04em] text-slate-950">Your current profile vs. {dashboard.role.title}</h2></div><button onClick={() => setActiveView("gap")} className="text-[12px] font-bold text-blue-600">View detail <ChevronRight size={14} className="inline" /></button></div><div className="mt-3 h-[260px] w-full"><ResponsiveContainer width="100%" height="100%"><RadarChart data={radarData} outerRadius="71%"><PolarGrid stroke="#E7EDF6" /><PolarAngleAxis dataKey="skill" tick={{ fill: "#8A98AB", fontSize: 10 }} /><PolarRadiusAxis domain={[0, 5]} tick={false} axisLine={false} /><RechartsRadar name="Required" dataKey="required" stroke="#14B8A6" fill="#14B8A6" fillOpacity={0.08} strokeWidth={2} strokeDasharray="5 4" /><RechartsRadar name="Current" dataKey="current" stroke="#2563EB" fill="#2563EB" fillOpacity={0.18} strokeWidth={2.5} /></RadarChart></ResponsiveContainer></div><div className="mt-1 flex justify-center gap-5 text-[11px] font-semibold text-slate-500"><span><i className="mr-1.5 inline-block h-2 w-2 rounded-full bg-blue-600" />Current level</span><span><i className="mr-1.5 inline-block h-2 w-2 rounded-full bg-teal-400" />Role requirement</span></div></div>
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6"><div className="flex items-start justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Top skill gaps</p><h2 className="mt-2 font-display text-[20px] font-bold tracking-[-0.04em] text-slate-950">Where to focus next</h2></div><div className="rounded-lg bg-amber-50 p-2 text-amber-600"><Target size={17} /></div></div><div className="mt-5 space-y-4">{analysis.majorGaps.slice(0, 4).map((item: GapItem, index: number) => <button key={item.skillId} onClick={() => setActiveView("gap")} className="group flex w-full items-center gap-3 text-left"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-[11px] font-bold text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600">0{index + 1}</span><span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-3"><span className="truncate text-[13px] font-bold text-slate-800">{item.skillName}</span><span className="text-[11px] font-bold text-rose-500">-{item.gap} lvl</span></span><span className="mt-1.5 block"><LevelBars current={item.currentLevel} required={item.requiredLevel} /></span></span><ChevronRight size={14} className="text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-blue-500" /></button>)}</div><div className="mt-6 border-t border-slate-100 pt-4"><p className="text-[11px] leading-5 text-slate-400"><Lightbulb size={13} className="mr-1 inline text-amber-500" />Recommendations are ranked by gap × role importance.</p></div></div>
    </div>
    <div className="mt-5 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6"><div className="flex items-center justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Next 3 actions</p><h2 className="mt-2 font-display text-[20px] font-bold tracking-[-0.04em] text-slate-950">Small steps, visible progress</h2></div><button onClick={() => setActiveView("roadmap")} className="text-[12px] font-bold text-blue-600">See all <ChevronRight size={14} className="inline" /></button></div><div className="mt-5 grid gap-3 md:grid-cols-3">{dashboard.nextActions.map((item: RoadmapItem, index: number) => <div key={item.id} className="flex gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4"><div className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-[11px] font-bold ${index === 0 ? "bg-blue-600 text-white" : "bg-white text-slate-500 ring-1 ring-slate-200"}`}>0{index + 1}</div><div className="min-w-0"><p className="truncate text-[12px] font-bold text-slate-800">{item.resource.title}</p><div className="mt-2 flex items-center gap-2"><Pill tone={index === 0 ? "blue" : "slate"}>{item.skillName}</Pill><span className="text-[10px] text-slate-400">{item.resource.estimatedHours}h</span></div></div></div>)}</div></div>
  </div>;
}

function RoleSelection({ roles, selectedRoleId, setSelectedRoleId, onGenerate, onCustomRole }: { roles: Role[]; selectedRoleId: string; setSelectedRoleId: (id: string) => void; onGenerate: () => void; onCustomRole: (title: string) => void }) {
  const [search, setSearch] = useState("");
  const [customTitle, setCustomTitle] = useState("");
  const filtered = roles.filter((role) => role.title.toLowerCase().includes(search.toLowerCase()) || role.shortDescription.toLowerCase().includes(search.toLowerCase()));
  return <div><SectionHeading eyebrow="Choose your direction" title="Explore career paths." description="Pick a target role or define a custom destination and we’ll map the skills that move the needle." action={<button onClick={onGenerate} className="pressable rounded-xl bg-blue-600 px-4 py-2.5 text-[12px] font-bold text-white shadow-sm shadow-blue-600/20">Analyze this role <ArrowUpRight size={14} className="ml-1 inline" /></button>} /><div className="relative mb-5 max-w-md"><Search size={16} className="absolute left-3.5 top-3.5 text-slate-400" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search preset roles..." className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-4 text-[13px] outline-none transition placeholder:text-slate-400 focus:border-blue-400 focus:ring-4 focus:ring-blue-50" /></div><div className="mb-5 rounded-2xl border border-dashed border-blue-200 bg-blue-50/50 p-5"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-blue-600">Not seeing your role?</p><h2 className="mt-2 font-display text-[19px] font-bold tracking-[-0.04em] text-slate-950">Define your own target role</h2><p className="mt-1 text-[12px] leading-5 text-slate-500">We’ll match it to the existing catalog offline, or use the configured AI layer when available.</p></div><Pill tone="teal"><Sparkles size={12} className="mr-1" />AI + fallback</Pill></div><div className="mt-4 flex flex-col gap-2 sm:flex-row"><input value={customTitle} onChange={(event) => setCustomTitle(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && customTitle.trim()) onCustomRole(customTitle.trim()); }} placeholder="e.g. Climate Data Product Lead" className="min-w-0 flex-1 rounded-xl border border-white bg-white px-3.5 py-3 text-[13px] outline-none ring-1 ring-blue-100 focus:border-blue-400 focus:ring-4 focus:ring-blue-100" /><button onClick={() => { if (customTitle.trim()) onCustomRole(customTitle.trim()); }} disabled={!customTitle.trim()} className="pressable rounded-xl bg-slate-950 px-4 py-3 text-[12px] font-bold text-white disabled:opacity-40">Build my role <ArrowUpRight size={14} className="ml-1 inline" /></button></div></div><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{filtered.map((role) => { const selected = selectedRoleId === role.id; return <button key={role.id} onClick={() => setSelectedRoleId(role.id)} className={`group rounded-2xl border p-5 text-left transition ${selected ? "border-blue-500 bg-blue-50/50 shadow-lg shadow-blue-500/10" : "border-slate-200 bg-white hover:-translate-y-0.5 hover:border-blue-200 hover:shadow-md"}`}><div className="flex items-start justify-between"><div className="flex h-10 w-10 items-center justify-center rounded-xl text-white shadow-sm" style={{ background: role.accent }}>{role.id.includes("data") || role.id.includes("ai") ? <Database size={18} /> : role.id.includes("cloud") || role.id.includes("devops") ? <Network size={18} /> : role.id.includes("security") ? <ShieldCheck size={18} /> : role.id.includes("ux") ? <Palette size={18} /> : <Code2 size={18} />}</div>{selected ? <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-600 text-white"><Check size={14} /></span> : <ChevronRight size={17} className="text-slate-300 transition group-hover:translate-x-1 group-hover:text-blue-500" />}</div><h3 className="mt-5 font-display text-[18px] font-bold tracking-[-0.04em] text-slate-900">{role.title}</h3><p className="mt-2 min-h-[42px] text-[12px] leading-5 text-slate-500">{role.shortDescription}</p><div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4 text-[11px] font-semibold text-slate-400"><span>{role.requiredSkills.length} core skills</span><span className={selected ? "text-blue-600" : "text-slate-400"}>{selected ? "Selected" : "Select role"}</span></div></button> })}</div></div>;
}

function GapAnalysis({ analysis, onBuildRoadmap }: { analysis: any; onBuildRoadmap: () => void }) {
  const radarData = analysis.items.map((item: GapItem) => ({ skill: item.skillName.length > 14 ? `${item.skillName.slice(0, 12)}…` : item.skillName, required: item.requiredLevel, current: item.currentLevel }));
  return <div><SectionHeading eyebrow="Your personalized analysis" title={`The gap to ${analysis.role.title}.`} description="We compare your current self-assessment with what strong performance in the role requires." action={<button onClick={onBuildRoadmap} className="pressable rounded-xl bg-blue-600 px-4 py-2.5 text-[12px] font-bold text-white shadow-sm shadow-blue-600/20">Generate roadmap <ArrowUpRight size={14} className="ml-1 inline" /></button>} /><div className="grid gap-5 xl:grid-cols-[0.8fr_1.2fr]"><div className="rounded-2xl border border-slate-200 bg-white p-6"><div className="flex items-center gap-6"><ReadinessRing value={analysis.readiness} /><div><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Overall readiness</p><p className="mt-2 text-[15px] font-bold text-slate-900">You’re closer than you think.</p><p className="mt-2 text-[12px] leading-5 text-slate-500">You already have a solid base. Focus on the four high-impact gaps below to create the most momentum.</p></div></div><div className="mt-8 space-y-4 border-t border-slate-100 pt-6"><div className="flex items-center justify-between text-[12px]"><span className="font-semibold text-slate-600">Skills at target</span><span className="font-bold text-teal-600">{analysis.items.filter((item: GapItem) => item.gap === 0).length} / {analysis.items.length}</span></div><div className="h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-teal-500" style={{ width: `${(analysis.items.filter((item: GapItem) => item.gap === 0).length / analysis.items.length) * 100}%` }} /></div><div className="flex items-center justify-between text-[12px]"><span className="font-semibold text-slate-600">Average gap</span><span className="font-bold text-amber-600">{(analysis.items.reduce((sum: number, item: GapItem) => sum + item.gap, 0) / analysis.items.length).toFixed(1)} levels</span></div></div><div className="mt-7 rounded-xl bg-blue-50 p-4 text-[11px] leading-5 text-blue-800"><Lightbulb size={14} className="mr-1 inline text-blue-600" /><strong>How this works:</strong> each gap is multiplied by the role’s importance score. That’s why the roadmap starts with high-leverage skills, not just the biggest ones.</div></div><div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6"><div className="flex items-start justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Skill map</p><h2 className="mt-2 font-display text-[20px] font-bold tracking-[-0.04em] text-slate-950">Current vs. required level</h2></div><div className="flex gap-3 text-[11px] font-semibold text-slate-500"><span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-blue-600" />You</span><span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-teal-400" />Role</span></div></div><div className="mt-2 h-[300px] w-full"><ResponsiveContainer width="100%" height="100%"><RadarChart data={radarData} outerRadius="73%"><PolarGrid stroke="#E7EDF6" /><PolarAngleAxis dataKey="skill" tick={{ fill: "#7D8B9E", fontSize: 9 }} /><PolarRadiusAxis domain={[0, 5]} tick={{ fill: "#CBD5E1", fontSize: 9 }} axisLine={false} /><RechartsRadar dataKey="required" stroke="#14B8A6" fill="#14B8A6" fillOpacity={0.08} strokeWidth={2} strokeDasharray="5 4" /><RechartsRadar dataKey="current" stroke="#2563EB" fill="#2563EB" fillOpacity={0.16} strokeWidth={2.5} /></RadarChart></ResponsiveContainer></div></div></div><div className="mt-5 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6"><div className="flex items-start justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Explainability layer</p><h2 className="mt-2 font-display text-[20px] font-bold tracking-[-0.04em] text-slate-950">Why these recommendations?</h2></div><Pill tone="amber"><Sparkles size={12} className="mr-1" />{analysis.explanationMode}</Pill></div><div className="mt-5 grid gap-3 md:grid-cols-2">{analysis.majorGaps.map((item: GapItem, index: number) => <div key={item.skillId} className="rounded-xl border border-slate-100 bg-slate-50/60 p-4"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-white text-[11px] font-bold text-blue-600 ring-1 ring-slate-200">0{index + 1}</span><span className="text-[13px] font-bold text-slate-800">{item.skillName}</span></div><Pill tone={item.importance >= 5 ? "rose" : "amber"}>{item.importance}/5 importance</Pill></div><p className="mt-3 text-[12px] leading-5 text-slate-500">{item.explanation}</p></div>)}</div><p className="mt-5 text-[11px] text-slate-400"><ShieldCheck size={13} className="mr-1 inline text-teal-600" /> The demo uses a deterministic fallback so the experience is always available. An LLM can make the copy more natural when configured.</p></div></div>;
}

function RoadmapCard({ item, onStatusChange }: { item: RoadmapItem; onStatusChange: (itemId: string, status: RoadmapStatus) => void }) {
  const resourceIcons: Record<string, React.ReactNode> = { course: <BookOpen size={15} />, project: <Rocket size={15} />, certification: <ShieldCheck size={15} /> };
  return <div className={`card-lift rounded-2xl border bg-white p-4 transition ${item.status === "completed" ? "border-teal-100 opacity-75" : "border-slate-200"}`}><div className="flex items-start justify-between gap-3"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600">{resourceIcons[item.resource.type]}</div><StatusBadge status={item.status} /></div><p className="mt-4 text-[11px] font-bold uppercase tracking-[0.12em] text-blue-600">{item.skillName}</p><h3 className="mt-1 text-[13px] font-bold leading-5 text-slate-900">{item.resource.title}</h3><p className="mt-2 line-clamp-2 text-[11px] leading-5 text-slate-500">{item.reasonText}</p><div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 text-[10px] font-semibold text-slate-400"><span className="flex items-center gap-1"><Clock3 size={12} /> {item.resource.estimatedHours} hours</span><span>{item.resource.provider}</span></div>{item.status !== "completed" && <div className="mt-3 flex gap-2">{item.status === "pending" && <button onClick={() => onStatusChange(item.id, "in_progress")} className="flex-1 rounded-lg border border-slate-200 py-2 text-[11px] font-bold text-slate-600 transition hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700">Start</button>}<button onClick={() => onStatusChange(item.id, "completed")} className="flex-1 rounded-lg bg-slate-950 py-2 text-[11px] font-bold text-white transition hover:bg-teal-600">Mark complete</button></div>}</div>;
}

function RoleRequirementsEditor({ role, onSave }: { role: Role; onSave: (requiredSkills: Role["requiredSkills"]) => void }) {
  const [draft, setDraft] = useState(role.requiredSkills.map((item) => ({ ...item })));
  useEffect(() => setDraft(role.requiredSkills.map((item) => ({ ...item }))), [role.id, role.requiredSkills]);
  return <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50/60 p-4"><div className="flex items-start justify-between gap-4"><div><p className="text-[11px] font-bold uppercase tracking-[0.14em] text-amber-700">Demo control</p><p className="mt-1 text-[12px] leading-5 text-amber-900">Change a role requirement and watch the roadmap re-rank on refresh.</p></div><button onClick={() => onSave(draft)} className="pressable rounded-lg bg-amber-600 px-3 py-2 text-[11px] font-bold text-white">Apply update <Check size={13} className="ml-1 inline" /></button></div><div className="mt-4 grid gap-3 md:grid-cols-2">{draft.slice(0, 4).map((requirement, index) => <div key={requirement.skillId} className="rounded-lg bg-white/80 p-3"><div className="flex items-center justify-between text-[11px] font-bold text-slate-700"><span>{requirement.skillId.replaceAll("-", " ")}</span><span className="text-amber-700">L{requirement.minLevel} · {requirement.importance}/5</span></div><div className="mt-2 flex gap-3"><label className="flex-1 text-[10px] font-semibold text-slate-400">Minimum level<input type="range" min="1" max="5" value={requirement.minLevel} onChange={(event) => setDraft(draft.map((item, itemIndex) => itemIndex === index ? { ...item, minLevel: Number(event.target.value) } : item))} className="mt-1 w-full accent-amber-600" /></label><label className="flex-1 text-[10px] font-semibold text-slate-400">Importance<input type="range" min="1" max="5" value={requirement.importance} onChange={(event) => setDraft(draft.map((item, itemIndex) => itemIndex === index ? { ...item, importance: Number(event.target.value) } : item))} className="mt-1 w-full accent-amber-600" /></label></div></div>)}</div></div>;
}

function Roadmap({ roadmap, role, onStatusChange, onGenerate, requirementsUpdatedAt, onUpdateRequirements }: { roadmap: RoadmapItem[]; role: Role; onStatusChange: (itemId: string, status: RoadmapStatus) => void; onGenerate: () => void; requirementsUpdatedAt?: number; onUpdateRequirements: (requiredSkills: Role["requiredSkills"]) => void }) {
  const [showEditor, setShowEditor] = useState(false);
  const columns: Array<[RoadmapStatus, string, string]> = [["pending", "Pending", "Your next skills to unlock"], ["in_progress", "In progress", "Keep the momentum going"], ["completed", "Completed", "Proof you’re building range"]];
  return <div><SectionHeading eyebrow={`${role.title} path`} title="Your roadmap, in motion." description="A prioritized sequence of resources and proof-of-work. Complete a step or change a requirement and the rest will adapt." action={<div className="flex gap-2"><button onClick={() => setShowEditor((value) => !value)} className="pressable rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-[12px] font-bold text-amber-800">{showEditor ? "Close editor" : "Edit requirements"}</button><button onClick={onGenerate} className="pressable rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-[12px] font-bold text-slate-700 shadow-sm hover:border-blue-200 hover:text-blue-600">Refresh roadmap <TrendingUp size={14} className="ml-1 inline" /></button></div>} />{requirementsUpdatedAt && <div className="mb-5 flex items-center gap-3 rounded-2xl border border-teal-200 bg-teal-50 p-4 text-[12px] font-semibold text-teal-800"><CheckCircle2 size={18} className="shrink-0 text-teal-600" /><span><strong>Role requirements updated — roadmap refreshed.</strong> Your target changed, so priorities were recomputed.</span></div>}{showEditor && <RoleRequirementsEditor role={role} onSave={(next) => { onUpdateRequirements(next); setShowEditor(false); }} />}<div className="mb-5 mt-5 flex flex-wrap items-center gap-3 rounded-2xl border border-blue-100 bg-blue-50/60 p-4 text-[12px] text-blue-800"><div className="flex h-8 w-8 items-center justify-center rounded-xl bg-white text-blue-600 shadow-sm"><Zap size={16} /></div><p><strong>Adaptive by design:</strong> finishing a roadmap item raises that skill by one level, while changing requirements updates every remaining priority.</p></div><div className="grid items-start gap-5 xl:grid-cols-3">{columns.map(([status, title, subcopy]) => { const items = roadmap.filter((item) => item.status === status); return <section key={status} className="min-h-[320px] rounded-2xl bg-slate-100/70 p-3"><div className="flex items-center justify-between px-2 py-2"><div><h2 className="text-[13px] font-bold text-slate-800">{title} <span className="ml-1 rounded-full bg-white px-1.5 py-0.5 text-[10px] text-slate-400">{items.length}</span></h2><p className="mt-1 text-[10px] text-slate-400">{subcopy}</p></div>{status === "pending" ? <Circle size={16} className="text-slate-400" /> : status === "in_progress" ? <CircleDot size={16} className="text-blue-500" /> : <CheckCircle2 size={16} className="text-teal-500" />}</div><div className="mt-2 space-y-3">{items.length === 0 ? <div className="rounded-xl border border-dashed border-slate-300 p-5 text-center text-[11px] text-slate-400">Nothing here yet.</div> : items.map((item) => <RoadmapCard key={item.id} item={item} onStatusChange={onStatusChange} />)}</div></section> })}</div></div>;
}

function Progress({ dashboard, roadmap, setActiveView }: { dashboard: any; roadmap: RoadmapItem[]; setActiveView: (id: ViewId) => void }) {
  const completed = roadmap.filter((item) => item.status === "completed").length;
  const total = roadmap.length;
  const weekBars = [36, 52, 44, 70, 58, 84, 69, 94, 78, 100, 88, 100];
  return <div><SectionHeading eyebrow="Keep the flywheel turning" title="Progress you can feel." description="A quick view of the habits and milestones carrying you toward your target role." action={<button onClick={() => setActiveView("roadmap")} className="pressable rounded-xl bg-slate-950 px-4 py-2.5 text-[12px] font-bold text-white">Continue learning <ArrowUpRight size={14} className="ml-1 inline" /></button>} /><div className="grid gap-5 xl:grid-cols-[1.1fr_0.9fr]"><div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6"><div className="flex items-start justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Momentum over time</p><h2 className="mt-2 font-display text-[20px] font-bold tracking-[-0.04em] text-slate-950">Your consistency is compounding.</h2></div><TrendingUp size={20} className="text-teal-500" /></div><div className="mt-10 flex h-[190px] items-end gap-2 border-b border-l border-slate-100 px-3 pb-0 pt-5 sm:gap-4">{weekBars.map((height, index) => <div key={index} className="group flex h-full flex-1 flex-col items-center justify-end gap-2"><div className="w-full max-w-[24px] rounded-t-md bg-gradient-to-t from-blue-600 to-teal-400 transition group-hover:from-blue-500 group-hover:to-teal-300" style={{ height: `${height}%` }} /><span className="text-[9px] text-slate-400">{index + 1}</span></div>)}</div><div className="mt-4 flex justify-between text-[10px] text-slate-400"><span>12 weeks ago</span><span>This week</span></div></div><div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6"><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Milestone snapshot</p><div className="mt-6 flex items-center gap-5"><ReadinessRing value={dashboard.readiness} size="small" /><div><p className="font-display text-[25px] font-bold tracking-[-0.05em] text-slate-950">{completed} <span className="text-[16px] text-slate-400">of {total} steps</span></p><p className="mt-1 text-[12px] text-slate-500">completed in your current path</p></div></div><div className="mt-7 space-y-4"><div><div className="mb-2 flex justify-between text-[11px] font-semibold"><span className="text-slate-500">Roadmap progress</span><span className="text-blue-600">{total ? Math.round((completed / total) * 100) : 0}%</span></div><div className="h-2 rounded-full bg-slate-100"><div className="h-full rounded-full bg-blue-600" style={{ width: `${total ? (completed / total) * 100 : 0}%` }} /></div></div><div className="flex items-center justify-between rounded-xl bg-teal-50 p-3 text-[11px] text-teal-800"><span><Sparkles size={13} className="mr-1 inline" />Most improved</span><strong>React +1 level</strong></div></div></div></div><div className="mt-5 grid gap-5 lg:grid-cols-2"><div className="rounded-2xl border border-slate-200 bg-white p-5"><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Skills mastered</p><div className="mt-4 flex flex-wrap gap-2">{dashboard.masteredSkills.map((skill: string) => <Pill key={skill} tone="teal"><Check size={11} className="mr-1" />{skill}</Pill>)}</div></div><div className="rounded-2xl border border-slate-200 bg-white p-5"><p className="text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">Still on your radar</p><div className="mt-4 flex flex-wrap gap-2">{dashboard.remainingSkills.slice(0, 8).map((skill: string) => <Pill key={skill} tone="slate">{skill}</Pill>)}</div></div></div></div>;
}

function ProfileSetup({ profile, setProfile, onSave }: { profile: Profile; setProfile: (profile: Profile) => void; onSave: (skills: typeof defaultUserSkills) => void }) {
  const [step, setStep] = useState(0);
  const [skillsState, setSkillsState] = useState(defaultUserSkills);
  const steps = ["About you", "Interests", "Experience", "Target role", "Self-rating"];
  const update = (patch: Partial<Profile>) => setProfile({ ...profile, ...patch });
  const next = () => setStep((value) => Math.min(steps.length - 1, value + 1));
  return <div><SectionHeading eyebrow="Make it yours" title="Tune your starting point." description="A few honest inputs make the recommendations feel like they were built for you." /><div className="mx-auto max-w-3xl rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-8"><div className="mb-9 flex items-center justify-between gap-2">{steps.map((label, index) => <div key={label} className="flex flex-1 items-center gap-2"><div className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[11px] font-bold ${index <= step ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-400"}`}>{index < step ? <Check size={13} /> : index + 1}</div><span className={`hidden text-[11px] font-semibold sm:block ${index === step ? "text-slate-900" : "text-slate-400"}`}>{label}</span>{index < steps.length - 1 && <div className={`h-px flex-1 ${index < step ? "bg-blue-400" : "bg-slate-200"}`} />}</div>)}</div>{step === 0 && <div><h2 className="font-display text-[24px] font-bold tracking-[-0.04em] text-slate-950">Start with the basics.</h2><p className="mt-2 text-[13px] text-slate-500">We’ll use this context to calibrate your path.</p><label className="mt-7 block text-[12px] font-bold text-slate-700">Name<input value={profile.name} onChange={(event) => update({ name: event.target.value })} className="mt-2 w-full rounded-xl border border-slate-200 px-3.5 py-3 text-[13px] outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-50" /></label><label className="mt-5 block text-[12px] font-bold text-slate-700">Education<select value={profile.education} onChange={(event) => update({ education: event.target.value })} className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-[13px] outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-50">{educationOptions.map((option) => <option key={option}>{option}</option>)}</select></label></div>}{step === 1 && <div><h2 className="font-display text-[24px] font-bold tracking-[-0.04em] text-slate-950">What pulls you in?</h2><p className="mt-2 text-[13px] text-slate-500">Choose the themes you want your work to include.</p><div className="mt-7 grid gap-3 sm:grid-cols-2">{interestOptions.map((interest) => { const checked = profile.interests.includes(interest); return <button key={interest} onClick={() => update({ interests: checked ? profile.interests.filter((item) => item !== interest) : [...profile.interests, interest] })} className={`flex items-center justify-between rounded-xl border p-4 text-left text-[13px] font-semibold transition ${checked ? "border-blue-400 bg-blue-50 text-blue-700" : "border-slate-200 text-slate-600 hover:border-blue-200"}`}><span>{interest}</span>{checked ? <CheckCircle2 size={17} /> : <Circle size={17} className="text-slate-300" />}</button> })}</div></div>}{step === 2 && <div><h2 className="font-display text-[24px] font-bold tracking-[-0.04em] text-slate-950">Where are you today?</h2><p className="mt-2 text-[13px] text-slate-500">No judgment — this sets the right level of stretch.</p><div className="mt-7 grid gap-3 sm:grid-cols-2">{experienceOptions.map((option) => <button key={option} onClick={() => update({ experienceLevel: option })} className={`rounded-xl border p-4 text-left text-[13px] font-semibold transition ${profile.experienceLevel === option ? "border-blue-400 bg-blue-50 text-blue-700" : "border-slate-200 text-slate-600 hover:border-blue-200"}`}>{option}</button>)}</div></div>}{step === 3 && <div><h2 className="font-display text-[24px] font-bold tracking-[-0.04em] text-slate-950">What role are you moving toward?</h2><p className="mt-2 text-[13px] text-slate-500">You can change this later as your interests evolve.</p><div className="mt-7 grid gap-3 sm:grid-cols-2">{["frontend-developer", "data-analyst", "full-stack-developer", "product-manager"].map((roleId) => <button key={roleId} onClick={() => update({ careerGoal: roleId })} className={`rounded-xl border p-4 text-left transition ${profile.careerGoal === roleId ? "border-blue-400 bg-blue-50" : "border-slate-200 hover:border-blue-200"}`}><span className="text-[13px] font-bold capitalize text-slate-800">{roleId.replaceAll("-", " ")}</span><span className="mt-1 block text-[11px] text-slate-400">Personalized skill map + roadmap</span></button>)}</div></div>}{step === 4 && <div><h2 className="font-display text-[24px] font-bold tracking-[-0.04em] text-slate-950">Give yourself a signal.</h2><p className="mt-2 text-[13px] text-slate-500">Drag the sliders to your current comfort level. You can refine this anytime.</p><div className="mt-7 space-y-5">{skillsState.slice(0, 5).map((item) => <label key={item.skillId} className="block"><div className="mb-2 flex items-center justify-between text-[12px] font-bold text-slate-700"><span className="capitalize">{item.skillId.replaceAll("-", " ")}</span><span className="text-blue-600">{item.currentLevel}/5</span></div><input type="range" min="0" max="5" value={item.currentLevel} onChange={(event) => setSkillsState(skillsState.map((skill) => skill.skillId === item.skillId ? { ...skill, currentLevel: Number(event.target.value) } : skill))} className="w-full accent-blue-600" /><div className="mt-1 flex justify-between text-[9px] text-slate-400"><span>New</span><span>Working</span><span>Strong</span></div></label>)}</div></div>}<div className="mt-9 flex justify-between border-t border-slate-100 pt-5"><button onClick={() => setStep((value) => Math.max(0, value - 1))} disabled={step === 0} className="rounded-xl px-3 py-2 text-[12px] font-bold text-slate-400 disabled:opacity-40">Back</button>{step === steps.length - 1 ? <button onClick={() => onSave(skillsState)} className="pressable rounded-xl bg-blue-600 px-5 py-2.5 text-[12px] font-bold text-white">Save my path <Check size={14} className="ml-1 inline" /></button> : <button onClick={next} className="pressable rounded-xl bg-slate-950 px-5 py-2.5 text-[12px] font-bold text-white">Continue <ChevronRight size={14} className="ml-1 inline" /></button>}</div></div></div>;
}

export default function Home() {
  const [mode, setMode] = useState<"landing" | "workspace">("landing");
  const [activeView, setActiveView] = useState<ViewId>("overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selectedRoleId, setSelectedRoleId] = useState(defaultProfile.careerGoal);
  const [profile, setProfile] = useState<Profile>({ ...defaultProfile, interests: [...defaultProfile.interests] });
  const utils = trpc.useUtils();
  const metaQuery = trpc.skillpath.meta.useQuery();
  const rolesQuery = trpc.skillpath.roles.useQuery();
  const roleInput = useMemo(() => ({ roleId: selectedRoleId }), [selectedRoleId]);
  const analysisQuery = trpc.skillpath.gapAnalysis.useQuery(roleInput);
  const roadmapQuery = trpc.skillpath.roadmap.useQuery();
  const dashboardQuery = trpc.skillpath.dashboard.useQuery();
  const saveProfile = trpc.skillpath.saveProfile.useMutation({ onSuccess: () => { void utils.skillpath.meta.invalidate(); void utils.skillpath.gapAnalysis.invalidate(); void utils.skillpath.roadmap.invalidate(); void utils.skillpath.dashboard.invalidate(); toast.success("Your path is updated"); setActiveView("overview"); } });
  const generateRoadmap = trpc.skillpath.generateRoadmap.useMutation({ onSuccess: () => { void utils.skillpath.gapAnalysis.invalidate(); void utils.skillpath.roadmap.invalidate(); void utils.skillpath.dashboard.invalidate(); toast.success("Roadmap refreshed around your target role"); setActiveView("roadmap"); } });
  const customRole = trpc.skillpath.customRole.useMutation({ onSuccess: (result) => { setSelectedRoleId(result.role.id); void utils.skillpath.roles.invalidate(); void utils.skillpath.gapAnalysis.invalidate(); void utils.skillpath.roadmap.invalidate(); void utils.skillpath.dashboard.invalidate(); toast.success(`${result.role.title} mapped with ${result.mode.toLowerCase()} recommendations`); setActiveView("gap"); } });
  const updateRole = trpc.skillpath.updateRole.useMutation({ onSuccess: (result) => { void utils.skillpath.roles.invalidate(); void utils.skillpath.gapAnalysis.invalidate(); void utils.skillpath.roadmap.invalidate(); void utils.skillpath.dashboard.invalidate(); toast.success(result.refreshed ? "Role requirements updated — roadmap refreshed" : "Role requirements saved"); setActiveView("roadmap"); } });
  const updateRoadmap = trpc.skillpath.updateRoadmap.useMutation({ onSuccess: (result) => { void utils.skillpath.gapAnalysis.invalidate(); void utils.skillpath.roadmap.invalidate(); void utils.skillpath.dashboard.invalidate(); if (result.status === "completed") toast.success("Nice work — your roadmap just adapted"); } });
  useEffect(() => { if (metaQuery.data?.profile && mode === "landing") { setProfile(metaQuery.data.profile); setSelectedRoleId(metaQuery.data.profile.careerGoal); } }, [metaQuery.data, mode]);
  useEffect(() => { if (dashboardQuery.data?.role?.id) setSelectedRoleId(dashboardQuery.data.role.id); }, [dashboardQuery.data?.role?.id]);
  if (mode === "landing") return <Landing onStart={() => setMode("workspace")} />;
  const analysis = analysisQuery.data;
  const dashboard = dashboardQuery.data;
  const roadmap = roadmapQuery.data;
  if (!analysis || !dashboard || !roadmap || !rolesQuery.data) return <div className="flex min-h-screen items-center justify-center bg-[#f8fbff]"><div className="text-center"><div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-blue-100 border-t-blue-600" /><p className="mt-4 text-[13px] font-semibold text-slate-500">Building your skill path…</p></div></div>;
  const handleGenerate = () => generateRoadmap.mutate({ roleId: selectedRoleId });
  const handleSaveProfile = (userSkills: typeof defaultUserSkills) => saveProfile.mutate({ ...profile, userSkills });
  const handleStatusChange = (itemId: string, status: RoadmapStatus) => updateRoadmap.mutate({ itemId, status });
  const handleCustomRole = (title: string) => customRole.mutate({ title });
  const handleUpdateRequirements = (requiredSkills: Role["requiredSkills"]) => updateRole.mutate({ roleId: roadmap.role.id, requiredSkills });
  return <div className="min-h-screen bg-[#f7faff] text-slate-950"><div className="flex min-h-screen"><Sidebar activeView={activeView} setActiveView={setActiveView} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />{mobileOpen && <button aria-label="Close navigation" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-30 bg-slate-950/20 lg:hidden" />}<div className="min-w-0 flex-1"><Topbar activeView={activeView} onMenu={() => setMobileOpen(true)} onExit={() => setMode("landing")} /><main className="mx-auto max-w-[1400px] px-5 py-8 lg:px-10 lg:py-10">{activeView === "overview" && <Overview dashboard={dashboard} analysis={analysis} setActiveView={setActiveView} />}{activeView === "role" && <RoleSelection roles={rolesQuery.data} selectedRoleId={selectedRoleId} setSelectedRoleId={setSelectedRoleId} onGenerate={handleGenerate} onCustomRole={handleCustomRole} />}{activeView === "gap" && <GapAnalysis analysis={analysis} onBuildRoadmap={handleGenerate} />}{activeView === "roadmap" && <Roadmap roadmap={roadmap.items} role={roadmap.role} requirementsUpdatedAt={roadmap.requirementsUpdatedAt} onStatusChange={handleStatusChange} onGenerate={handleGenerate} onUpdateRequirements={handleUpdateRequirements} />}{activeView === "progress" && <Progress dashboard={dashboard} roadmap={roadmap.items} setActiveView={setActiveView} />}{activeView === "profile" && <ProfileSetup profile={profile} setProfile={setProfile} onSave={handleSaveProfile} />}</main></div></div></div>;
}
