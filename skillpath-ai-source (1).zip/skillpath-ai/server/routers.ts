import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import {
  allowedStatuses,
  buildRoadmap,
  calculateGapAnalysis,
  defaultProfile,
  defaultUserSkills,
  getDashboard,
  getRole,
  interestOptions,
  roles,
  skills,
  type Profile,
  type RequiredSkill,
  type RoadmapStatus,
  type UserSkill,
} from "@shared/skillpath";
import { createHeuristicRole, matchOrCreateSkill, updateRoleRequirements } from "@shared/customRole";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

const state: {
  profile: Profile;
  userSkills: UserSkill[];
  selectedRoleId: string;
  completedSkillIds: string[];
  inProgressItemIds: string[];
  roadmap: ReturnType<typeof buildRoadmap>;
  requirementsUpdatedAt?: number;
} = {
  profile: { ...defaultProfile, interests: [...defaultProfile.interests] },
  userSkills: defaultUserSkills.map((item) => ({ ...item })),
  selectedRoleId: defaultProfile.careerGoal,
  completedSkillIds: [],
  inProgressItemIds: [],
  roadmap: [],
};

state.roadmap = buildRoadmap(state.selectedRoleId, state.userSkills, state.completedSkillIds, state.inProgressItemIds);

const profileInput = z.object({
  name: z.string().min(2).max(80).optional(),
  education: z.string().min(2).max(120),
  experienceLevel: z.string().min(2).max(80),
  interests: z.array(z.string()).min(1).max(8),
  careerGoal: z.string().min(2).max(120),
  userSkills: z.array(z.object({ skillId: z.string(), currentLevel: z.number().int().min(0).max(5), source: z.enum(["self-declared", "assessment"]) })).optional(),
});

const requiredSkillInput = z.object({ skillId: z.string().min(1), importance: z.number().int().min(1).max(5), minLevel: z.number().int().min(1).max(5) });

const refreshRoadmap = () => {
  state.roadmap = buildRoadmap(state.selectedRoleId, state.userSkills, state.completedSkillIds, state.inProgressItemIds);
};

async function createRoleFromTitle(title: string) {
  if (!process.env.AI_API_KEY) return { role: createHeuristicRole(title), mode: "Rule-based fallback" as const };
  try {
    const response = await invokeLLM({
      messages: [
        { role: "system", content: "You are a career taxonomy expert. Return only JSON with a skills array of 8 to 12 objects containing name, importance (1-5), and minLevel (1-5). Prefer common professional skills." },
        { role: "user", content: `Define the target skills for the role: ${title}` },
      ],
      response_format: { type: "json_schema", json_schema: { name: "custom_role_skills", strict: true, schema: { type: "object", properties: { skills: { type: "array", minItems: 8, maxItems: 12, items: { type: "object", properties: { name: { type: "string" }, importance: { type: "integer", minimum: 1, maximum: 5 }, minLevel: { type: "integer", minimum: 1, maximum: 5 } }, required: ["name", "importance", "minLevel"], additionalProperties: false } } }, required: ["skills"], additionalProperties: false } } },
    });
    const content = response.choices?.[0]?.message?.content;
    const parsed = typeof content === "string" ? JSON.parse(content) as { skills?: Array<{ name: string; importance: number; minLevel: number }> } : undefined;
    const aiSkills = parsed?.skills?.filter((skill) => skill.name).slice(0, 12) ?? [];
    if (aiSkills.length >= 8) {
      const requiredSkills: RequiredSkill[] = aiSkills.map((skill) => ({ skillId: matchOrCreateSkill(skill.name), importance: Math.max(1, Math.min(5, Math.round(skill.importance))), minLevel: Math.max(1, Math.min(5, Math.round(skill.minLevel))) }));
      const roleId = `custom-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 48)}`;
      const existing = roles.find((candidate) => candidate.id === roleId);
      const role = existing ?? { id: roleId, title: title.trim(), shortDescription: `An AI-shaped path for becoming a strong ${title.trim()}.`, accent: "#0F766E", requiredSkills };
      role.requiredSkills = requiredSkills;
      if (!existing) roles.push(role);
      return { role, mode: "AI-generated" as const };
    }
  } catch (error) {
    console.warn("[SkillPath] Custom role AI generation failed; using deterministic fallback.", error);
  }
  return { role: createHeuristicRole(title), mode: "Rule-based fallback" as const };
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  skillpath: router({
    meta: publicProcedure.query(() => ({ appName: "SkillPath AI", profile: state.profile, selectedRole: getRole(state.selectedRoleId), demoMode: true, explanationMode: "Rule-based fallback", interestOptions })),
    skills: publicProcedure.input(z.object({ category: z.string().optional() }).optional()).query(({ input }) => input?.category ? skills.filter((skill) => skill.category === input.category) : skills),
    roles: publicProcedure.query(() => roles),
    role: publicProcedure.input(z.object({ roleId: z.string() })).query(({ input }) => getRole(input.roleId)),
    customRole: publicProcedure.input(z.object({ title: z.string().min(2).max(120) })).mutation(async ({ input }) => {
      const { role, mode } = await createRoleFromTitle(input.title);
      state.selectedRoleId = role.id;
      state.profile.careerGoal = role.id;
      state.completedSkillIds = [];
      state.inProgressItemIds = [];
      refreshRoadmap();
      return { role, mode, items: state.roadmap };
    }),
    updateRole: publicProcedure.input(z.object({ roleId: z.string(), requiredSkills: z.array(requiredSkillInput).min(1).max(15) })).mutation(({ input }) => {
      const role = updateRoleRequirements(input.roleId, input.requiredSkills);
      const refreshed = state.selectedRoleId === input.roleId;
      if (refreshed) refreshRoadmap();
      state.requirementsUpdatedAt = Date.now();
      return { role, refreshed, requirementsUpdatedAt: state.requirementsUpdatedAt };
    }),
    saveProfile: publicProcedure.input(profileInput).mutation(({ input }) => {
      state.profile = { ...state.profile, ...input, name: input.name ?? state.profile.name, interests: [...input.interests] };
      state.selectedRoleId = input.careerGoal;
      state.completedSkillIds = [];
      state.inProgressItemIds = [];
      if (input.userSkills) state.userSkills = input.userSkills.map((item) => ({ ...item }));
      refreshRoadmap();
      return { profile: state.profile, userSkills: state.userSkills, roadmap: state.roadmap };
    }),
    gapAnalysis: publicProcedure.input(z.object({ roleId: z.string().optional() }).optional()).query(({ input }) => {
      if (input?.roleId && input.roleId !== state.selectedRoleId) { state.selectedRoleId = input.roleId; refreshRoadmap(); }
      return calculateGapAnalysis(state.selectedRoleId, state.userSkills);
    }),
    generateRoadmap: publicProcedure.input(z.object({ roleId: z.string() })).mutation(({ input }) => {
      state.selectedRoleId = input.roleId;
      state.profile.careerGoal = input.roleId;
      state.completedSkillIds = [];
      state.inProgressItemIds = [];
      refreshRoadmap();
      return { role: getRole(input.roleId), items: state.roadmap };
    }),
    roadmap: publicProcedure.query(() => ({ role: getRole(state.selectedRoleId), items: state.roadmap, explanationMode: "Rule-based fallback" as const, requirementsUpdatedAt: state.requirementsUpdatedAt })),
    updateRoadmap: publicProcedure.input(z.object({ itemId: z.string(), status: z.enum(allowedStatuses as [RoadmapStatus, ...RoadmapStatus[]]) })).mutation(({ input }) => {
      const item = state.roadmap.find((candidate) => candidate.id === input.itemId);
      if (!item) throw new Error("Roadmap item not found");
      if (input.status === "completed") {
        const existing = state.userSkills.find((skill) => skill.skillId === item.skillId);
        if (existing) existing.currentLevel = Math.min(5, existing.currentLevel + 1);
        else state.userSkills.push({ skillId: item.skillId, currentLevel: 1, source: "assessment" });
        if (!state.completedSkillIds.includes(item.skillId)) state.completedSkillIds.push(item.skillId);
        state.inProgressItemIds = state.inProgressItemIds.filter((id) => id !== item.id);
      } else if (input.status === "in_progress") {
        if (!state.inProgressItemIds.includes(item.id)) state.inProgressItemIds.push(item.id);
      } else state.inProgressItemIds = state.inProgressItemIds.filter((id) => id !== item.id);
      refreshRoadmap();
      return { items: state.roadmap, changedSkillId: item.skillId, status: input.status };
    }),
    dashboard: publicProcedure.query(() => getDashboard(state.selectedRoleId, state.userSkills, state.roadmap)),
  }),
});

export type AppRouter = typeof appRouter;
