export type SkillCategory = "Programming" | "Data" | "Tools" | "Cloud & DevOps" | "Professional";
export type ResourceType = "course" | "project" | "certification";
export type RoadmapStatus = "pending" | "in_progress" | "completed";

export type Skill = {
  id: string;
  name: string;
  category: SkillCategory;
  description: string;
};

export type RequiredSkill = {
  skillId: string;
  importance: number;
  minLevel: number;
};

export type Role = {
  id: string;
  title: string;
  shortDescription: string;
  accent: string;
  requiredSkills: RequiredSkill[];
};

export type LearningResource = {
  id: string;
  skillId: string;
  title: string;
  type: ResourceType;
  provider: string;
  estimatedHours: number;
  url: string;
};

export type UserSkill = {
  skillId: string;
  currentLevel: number;
  source: "self-declared" | "assessment";
};

export type Profile = {
  name: string;
  email: string;
  education: string;
  experienceLevel: string;
  interests: string[];
  careerGoal: string;
};

export type GapItem = {
  skillId: string;
  skillName: string;
  category: SkillCategory;
  requiredLevel: number;
  currentLevel: number;
  gap: number;
  importance: number;
  priorityScore: number;
  explanation: string;
};

export type RoadmapItem = {
  id: string;
  resourceId: string;
  skillId: string;
  skillName: string;
  resource: LearningResource;
  status: RoadmapStatus;
  priority: number;
  priorityScore: number;
  reasonText: string;
  addedAt: number;
  completedAt?: number;
};

const skillSeed: Array<[string, string, SkillCategory, string]> = [
  ["javascript", "JavaScript", "Programming", "Build interactive web experiences and server logic."],
  ["typescript", "TypeScript", "Programming", "Add reliable types and safer refactoring to JavaScript projects."],
  ["react", "React", "Programming", "Compose responsive interfaces from reusable components."],
  ["html-css", "HTML & CSS", "Programming", "Structure accessible pages and create polished layouts."],
  ["node", "Node.js", "Programming", "Run JavaScript on the server and build production APIs."],
  ["express", "Express", "Programming", "Create pragmatic REST services with Node.js."],
  ["python", "Python", "Programming", "Automate workflows and build data or backend applications."],
  ["java", "Java", "Programming", "Build scalable, strongly typed enterprise applications."],
  ["sql", "SQL", "Data", "Query, model, and transform relational data with confidence."],
  ["statistics", "Statistics", "Data", "Turn uncertainty and variation into useful decisions."],
  ["data-visualization", "Data Visualization", "Data", "Communicate patterns with clear, honest visual narratives."],
  ["pandas", "Pandas", "Data", "Clean and analyze tabular datasets efficiently."],
  ["numpy", "NumPy", "Data", "Use fast numerical computing for analytical workflows."],
  ["excel", "Excel", "Data", "Model scenarios and answer business questions quickly."],
  ["machine-learning", "Machine Learning", "Data", "Train, validate, and ship predictive models."],
  ["linear-algebra", "Linear Algebra", "Data", "Understand the mathematical building blocks of ML."],
  ["git", "Git", "Tools", "Collaborate safely and keep a clear history of changes."],
  ["testing", "Testing", "Tools", "Prevent regressions with focused automated checks."],
  ["api-design", "API Design", "Tools", "Design predictable interfaces that other teams can use."],
  ["graphql", "GraphQL", "Tools", "Let clients request the exact data they need."],
  ["docker", "Docker", "Cloud & DevOps", "Package applications consistently across environments."],
  ["kubernetes", "Kubernetes", "Cloud & DevOps", "Operate containerized workloads at scale."],
  ["aws", "AWS", "Cloud & DevOps", "Use core cloud services to build resilient systems."],
  ["terraform", "Terraform", "Cloud & DevOps", "Provision infrastructure through repeatable code."],
  ["ci-cd", "CI/CD", "Cloud & DevOps", "Automate build, test, and delivery pipelines."],
  ["linux", "Linux", "Cloud & DevOps", "Navigate and operate the systems behind modern products."],
  ["bash", "Bash Scripting", "Cloud & DevOps", "Automate repetitive operational work from the command line."],
  ["networking", "Networking", "Cloud & DevOps", "Understand the paths and protocols that connect systems."],
  ["monitoring", "Monitoring", "Cloud & DevOps", "Find issues early with useful signals and alerts."],
  ["cloud-security", "Cloud Security", "Cloud & DevOps", "Build secure cloud environments with least privilege."],
  ["communication", "Communication", "Professional", "Make complex work clear to teammates and stakeholders."],
  ["problem-solving", "Problem Solving", "Professional", "Break ambiguous challenges into practical next steps."],
  ["ux-ui", "UX/UI", "Professional", "Balance usability, hierarchy, and visual clarity."],
  ["accessibility", "Accessibility", "Professional", "Design inclusive experiences for more people."],
  ["product-strategy", "Product Strategy", "Professional", "Connect customer needs to measurable product choices."],
  ["user-research", "User Research", "Professional", "Learn what people need before deciding what to build."],
  ["roadmapping", "Roadmapping", "Professional", "Sequence initiatives around outcomes and constraints."],
  ["agile", "Agile & Scrum", "Professional", "Deliver iteratively with a healthy team cadence."],
  ["presentation", "Presentation", "Professional", "Tell a focused story that earns action and alignment."],
  ["stakeholder-management", "Stakeholder Management", "Professional", "Navigate priorities and decisions across teams."],
  ["system-design", "System Design", "Professional", "Shape reliable systems from requirements to trade-offs."],
  ["security-fundamentals", "Security Fundamentals", "Professional", "Recognize common vulnerabilities and secure defaults."],
  ["threat-modeling", "Threat Modeling", "Professional", "Anticipate abuse cases before they become incidents."],
  ["siem", "SIEM", "Tools", "Correlate security signals into actionable investigations."],
  ["incident-response", "Incident Response", "Professional", "Contain, learn from, and recover from security events."],
  ["cryptography", "Cryptography", "Professional", "Use modern primitives to protect data and identity."],
  ["react-native", "React Native", "Programming", "Extend React skills into native mobile products."],
  ["performance", "Performance", "Tools", "Measure and improve the speed users actually feel."],
  ["app-store", "App Store Delivery", "Tools", "Package, release, and monitor mobile applications."],
  ["tensorflow", "TensorFlow", "Data", "Build and serve deep learning models."],
  ["experiment-design", "Experiment Design", "Data", "Run thoughtful tests that separate signal from noise."],
  ["cloud-architecture", "Cloud Architecture", "Cloud & DevOps", "Compose cloud systems for scale, resilience, and cost."],
  ["cost-optimization", "Cost Optimization", "Cloud & DevOps", "Make engineering trade-offs visible in the cloud bill."],
  ["scripting", "Security Scripting", "Programming", "Automate security checks and investigation workflows."],
  ["observability", "Observability", "Cloud & DevOps", "Explain system behavior through logs, metrics, and traces."],
  ["design-systems", "Design Systems", "Professional", "Create reusable interface patterns that scale."],
  ["research-synthesis", "Research Synthesis", "Professional", "Turn qualitative evidence into product direction."],
  ["data-storytelling", "Data Storytelling", "Professional", "Frame evidence so the takeaway is memorable."],
  ["privacy", "Privacy by Design", "Professional", "Build products that treat personal data responsibly."],
  ["collaboration", "Collaboration", "Professional", "Create momentum across disciplines and working styles."],
];

export const skills: Skill[] = skillSeed.map(([id, name, category, description]) => ({ id, name, category, description }));

const role = (id: string, title: string, shortDescription: string, accent: string, requiredSkills: Array<[string, number, number]>): Role => ({
  id,
  title,
  shortDescription,
  accent,
  requiredSkills: requiredSkills.map(([skillId, importance, minLevel]) => ({ skillId, importance, minLevel })),
});

export const roles: Role[] = [
  role("frontend-developer", "Frontend Developer", "Turn product ideas into fast, accessible interfaces.", "#2563EB", [["javascript", 5, 4], ["react", 5, 4], ["typescript", 4, 3], ["html-css", 5, 4], ["git", 4, 3], ["testing", 4, 3], ["accessibility", 4, 3], ["api-design", 3, 2], ["performance", 4, 3], ["ux-ui", 3, 3]]),
  role("data-analyst", "Data Analyst", "Find the signal in messy data and make it useful.", "#0F766E", [["sql", 5, 4], ["excel", 4, 4], ["statistics", 5, 3], ["data-visualization", 5, 4], ["python", 4, 3], ["pandas", 4, 3], ["communication", 4, 4], ["data-storytelling", 4, 3], ["experiment-design", 3, 2]]),
  role("devops-engineer", "DevOps Engineer", "Create the reliable delivery systems teams depend on.", "#7C3AED", [["linux", 5, 4], ["docker", 5, 4], ["kubernetes", 4, 3], ["aws", 5, 3], ["terraform", 4, 3], ["ci-cd", 5, 4], ["networking", 4, 3], ["monitoring", 4, 3], ["git", 4, 3], ["bash", 3, 3], ["security-fundamentals", 3, 2]]),
  role("ai-ml-engineer", "AI / ML Engineer", "Build intelligent products from data to deployment.", "#DB2777", [["python", 5, 4], ["machine-learning", 5, 4], ["statistics", 5, 3], ["linear-algebra", 4, 3], ["pandas", 4, 3], ["numpy", 4, 3], ["tensorflow", 4, 3], ["sql", 3, 2], ["git", 3, 3], ["experiment-design", 4, 3], ["communication", 3, 3]]),
  role("full-stack-developer", "Full Stack Developer", "Own a feature from interface to data layer.", "#EA580C", [["javascript", 5, 4], ["typescript", 4, 3], ["react", 4, 3], ["node", 5, 4], ["express", 4, 3], ["sql", 4, 3], ["api-design", 5, 4], ["git", 4, 3], ["testing", 4, 3], ["docker", 3, 2], ["system-design", 4, 3], ["security-fundamentals", 3, 2]]),
  role("cybersecurity-analyst", "Cybersecurity Analyst", "Protect systems by spotting and responding to risk.", "#DC2626", [["networking", 5, 4], ["linux", 4, 3], ["security-fundamentals", 5, 4], ["threat-modeling", 4, 3], ["siem", 5, 3], ["incident-response", 5, 3], ["cryptography", 3, 2], ["cloud-security", 4, 3], ["scripting", 4, 3], ["communication", 3, 3]]),
  role("product-manager", "Product Manager", "Align people, evidence, and decisions around outcomes.", "#0891B2", [["product-strategy", 5, 4], ["user-research", 5, 3], ["roadmapping", 5, 4], ["communication", 5, 4], ["stakeholder-management", 5, 4], ["sql", 3, 2], ["data-visualization", 3, 2], ["agile", 4, 3], ["ux-ui", 3, 2], ["presentation", 4, 3], ["experiment-design", 4, 3]]),
  role("ux-designer", "UX Designer", "Make digital products feel obvious, useful, and human.", "#CA8A04", [["user-research", 5, 4], ["ux-ui", 5, 4], ["prototyping", 4, 3], ["accessibility", 4, 3], ["design-systems", 4, 3], ["communication", 4, 4], ["problem-solving", 4, 4], ["product-strategy", 3, 2], ["presentation", 4, 3], ["research-synthesis", 4, 3]]),
  role("mobile-developer", "Mobile Developer", "Ship thoughtful experiences people carry everywhere.", "#4F46E5", [["javascript", 4, 3], ["typescript", 4, 3], ["react-native", 5, 4], ["api-design", 4, 3], ["git", 4, 3], ["testing", 4, 3], ["ux-ui", 3, 3], ["performance", 4, 3], ["app-store", 4, 3], ["security-fundamentals", 3, 2], ["accessibility", 3, 2]]),
  role("cloud-architect", "Cloud Architect", "Design platforms that scale with confidence and clarity.", "#0369A1", [["cloud-architecture", 5, 4], ["aws", 5, 4], ["system-design", 5, 4], ["networking", 4, 4], ["security-fundamentals", 5, 4], ["docker", 4, 3], ["sql", 3, 2], ["communication", 4, 4], ["cost-optimization", 4, 3], ["presentation", 3, 3], ["terraform", 4, 3]]),
];

const resourceTemplates: Array<[ResourceType, string, string, number]> = [
  ["course", "Build a practical {skill} foundation", "Coursera", 6],
  ["project", "Ship a portfolio project with {skill}", "freeCodeCamp", 8],
  ["certification", "Validate your {skill} fluency", "YouTube", 4],
];

export const resources: LearningResource[] = skills.flatMap((skill, skillIndex) =>
  resourceTemplates.map(([type, title, provider, baseHours], resourceIndex) => ({
    id: `resource-${skill.id}-${resourceIndex + 1}`,
    skillId: skill.id,
    title: title.replace("{skill}", skill.name),
    type,
    provider,
    estimatedHours: baseHours + ((skillIndex + resourceIndex) % 4) * 2,
    url: "#",
  })),
);

export const defaultProfile: Profile = {
  name: "Maya Chen",
  email: "demo@skillpath.ai",
  education: "BSc Computer Science",
  experienceLevel: "Early career",
  interests: ["Building products", "Data", "Design"],
  careerGoal: "frontend-developer",
};

export const defaultUserSkills: UserSkill[] = [
  { skillId: "javascript", currentLevel: 4, source: "assessment" },
  { skillId: "react", currentLevel: 3, source: "self-declared" },
  { skillId: "typescript", currentLevel: 2, source: "self-declared" },
  { skillId: "html-css", currentLevel: 4, source: "assessment" },
  { skillId: "git", currentLevel: 3, source: "self-declared" },
  { skillId: "ux-ui", currentLevel: 2, source: "self-declared" },
  { skillId: "communication", currentLevel: 4, source: "assessment" },
  { skillId: "problem-solving", currentLevel: 4, source: "assessment" },
  { skillId: "testing", currentLevel: 1, source: "self-declared" },
  { skillId: "accessibility", currentLevel: 1, source: "self-declared" },
];

export const getSkill = (skillId: string) => skills.find((skill) => skill.id === skillId);
export const getRole = (roleId: string) => roles.find((item) => item.id === roleId) ?? roles[0];

const clampLevel = (level: number) => Math.max(0, Math.min(5, Math.round(level)));
const getCurrentLevel = (userSkills: UserSkill[], skillId: string) => clampLevel(userSkills.find((item) => item.skillId === skillId)?.currentLevel ?? 0);
const round = (value: number) => Math.round(value * 10) / 10;

export function calculateGapAnalysis(roleId: string, userSkills: UserSkill[]) {
  const selectedRole = getRole(roleId);
  const items: GapItem[] = selectedRole.requiredSkills.map((requirement) => {
    const skill = getSkill(requirement.skillId)!;
    const currentLevel = getCurrentLevel(userSkills, requirement.skillId);
    const gap = Math.max(0, requirement.minLevel - currentLevel);
    const priorityScore = gap * requirement.importance;
    return {
      skillId: requirement.skillId,
      skillName: skill.name,
      category: skill.category,
      requiredLevel: requirement.minLevel,
      currentLevel,
      gap,
      importance: requirement.importance,
      priorityScore,
      explanation: gap > 0
        ? `Recommended because ${skill.name} is rated ${requirement.importance}/5 importance for ${selectedRole.title} and your current level (${currentLevel}) is ${gap} point${gap === 1 ? "" : "s"} below the required level (${requirement.minLevel}).`
        : `${skill.name} is already at the target level for ${selectedRole.title}; keep it warm through real project practice.`,
    } satisfies GapItem;
  }).sort((a, b) => b.priorityScore - a.priorityScore || b.importance - a.importance);
  const requiredTotal = selectedRole.requiredSkills.reduce((sum, requirement) => sum + requirement.minLevel, 0);
  const earnedTotal = selectedRole.requiredSkills.reduce((sum, requirement) => sum + Math.min(getCurrentLevel(userSkills, requirement.skillId), requirement.minLevel), 0);
  return {
    role: selectedRole,
    items,
    readiness: round((earnedTotal / requiredTotal) * 100),
    majorGaps: items.filter((item) => item.gap > 0).slice(0, 4),
    explanationMode: "Rule-based fallback" as const,
  };
}

export function buildRoadmap(roleId: string, userSkills: UserSkill[], completedSkillIds: string[] = [], inProgressItemIds: string[] = [], now = Date.now()): RoadmapItem[] {
  const analysis = calculateGapAnalysis(roleId, userSkills);
  const completed = new Set(completedSkillIds);
  const inProgress = new Set(inProgressItemIds);
  const roadmap: RoadmapItem[] = [];
  analysis.items.filter((item) => item.gap > 0 || completed.has(item.skillId)).forEach((gapItem) => {
    const skillResources = resources.filter((resource) => resource.skillId === gapItem.skillId).slice(0, 2);
    skillResources.forEach((resource, index) => {
      const isCompleted = completed.has(gapItem.skillId);
      roadmap.push({
        id: `roadmap-${resource.id}`,
        resourceId: resource.id,
        skillId: gapItem.skillId,
        skillName: gapItem.skillName,
        resource,
        status: isCompleted ? "completed" : inProgress.has(`roadmap-${resource.id}`) ? "in_progress" : "pending",
        priority: Math.max(1, Math.min(5, gapItem.importance + (gapItem.gap >= 2 ? 1 : 0))),
        priorityScore: gapItem.priorityScore,
        reasonText: gapItem.explanation,
        addedAt: now + index,
        completedAt: isCompleted ? now : undefined,
      });
    });
  });
  return roadmap.sort((a, b) => {
    if (a.status === "completed" && b.status !== "completed") return 1;
    if (a.status !== "completed" && b.status === "completed") return -1;
    return b.priorityScore - a.priorityScore || a.addedAt - b.addedAt;
  });
}

export function getDashboard(roleId: string, userSkills: UserSkill[], roadmap: RoadmapItem[]) {
  const analysis = calculateGapAnalysis(roleId, userSkills);
  const mastered = analysis.items.filter((item) => item.gap === 0);
  const remaining = analysis.items.filter((item) => item.gap > 0);
  return {
    readiness: analysis.readiness,
    masteredCount: mastered.length,
    remainingCount: remaining.length,
    totalSkills: analysis.items.length,
    nextActions: roadmap.filter((item) => item.status !== "completed").slice(0, 3),
    masteredSkills: mastered.map((item) => item.skillName),
    remainingSkills: remaining.map((item) => item.skillName),
    role: analysis.role,
    explanationMode: analysis.explanationMode,
  };
}

export function rerankAfterCompletion(roleId: string, userSkills: UserSkill[], item: RoadmapItem) {
  const nextSkills = userSkills.map((skill) => ({ ...skill }));
  const existing = nextSkills.find((skill) => skill.skillId === item.skillId);
  if (existing) existing.currentLevel = clampLevel(existing.currentLevel + 1);
  else nextSkills.push({ skillId: item.skillId, currentLevel: 1, source: "assessment" });
  return {
    userSkills: nextSkills,
    roadmap: buildRoadmap(roleId, nextSkills, [item.skillId]),
  };
}

export const skillCategories = ["Programming", "Data", "Tools", "Cloud & DevOps", "Professional"] as const;
export const interestOptions = ["Building products", "Data", "Design", "Cloud systems", "Security", "Leading teams"];
export const experienceOptions = ["Student", "Early career", "Mid-level", "Career switcher"];
export const educationOptions = ["High school", "Bootcamp", "Undergraduate degree", "Graduate degree", "Self-taught"];

export const prototypeNotes = {
  seedSummary: `${skills.length} skills across ${skillCategories.length} categories, ${roles.length} target roles, and ${resources.length} learning resources`,
  auth: "Demo workspace is available immediately; Manus OAuth can be enabled for production identity.",
};

// Kept for simple smoke tests and build-time sanity checks.
export const skillpathInvariant = {
  rolesHaveRequirements: roles.every((item) => item.requiredSkills.length >= 8),
  resourcesAreNonEmpty: resources.length > 0,
};

void getCurrentLevel;
void round;
void getSkill;
void getRole;
void calculateGapAnalysis;
void buildRoadmap;
void getDashboard;
void rerankAfterCompletion;
void prototypeNotes;
void skillpathInvariant;
void clampLevel;

// The `prototyping` skill is referenced by the UX role and intentionally added here
// so the demo remains honest about the catalog even when the core role list evolves.
if (!skills.some((skill) => skill.id === "prototyping")) {
  skills.push({ id: "prototyping", name: "Prototyping", category: "Professional", description: "Make ideas tangible enough to test with real people." });
}
if (!roles.some((item) => item.id === "frontend-developer")) {
  throw new Error("SkillPath seed integrity check failed");
}

export const seedCounts = {
  skills: skills.length,
  roles: roles.length,
  resources: resources.length,
};

void seedCounts;

export const __all = { skills, roles, resources, defaultProfile, defaultUserSkills };
void __all;

export const noop = () => undefined;
void noop;

export const buildVersion = "demo-1.0";
void buildVersion;

export const recommendationPolicy = "gap × importance, sorted descending";
void recommendationPolicy;

export const fallbackGuarantee = "Every explanation and roadmap is deterministic when no AI key is configured.";
void fallbackGuarantee;

export const allowedStatuses: RoadmapStatus[] = ["pending", "in_progress", "completed"];
void allowedStatuses;

export const categoryCount = skillCategories.length;
void categoryCount;

export const roleCount = roles.length;
void roleCount;

export const resourceCount = resources.length;
void resourceCount;

export const skillCount = skills.length;
void skillCount;

export const completionRule = "Completing a roadmap item raises that skill by one level, then recomputes every remaining priority.";
void completionRule;

export const demoUser = { email: defaultProfile.email, password: "demo1234" };
void demoUser;

export const docs = { readiness: "100 × sum(min(current, required)) / sum(required)" };
void docs;

export const appName = "SkillPath AI";
void appName;

export const appTagline = "A clear next step for the career you want.";
void appTagline;

export const gradient = ["#2563EB", "#14B8A6"] as const;
void gradient;

export const version = "2026.09";
void version;

export const schemaNames = ["User", "Skill", "Role", "UserSkill", "LearningResource", "RoadmapItem"] as const;
void schemaNames;

export const emptyStateCopy = "No gap is a good gap. Choose another role to explore your next edge.";
void emptyStateCopy;

export const explainabilityCopy = "Every recommendation shows the skill gap and the role importance behind it.";
void explainabilityCopy;

export const adaptationCopy = "When you complete a step, SkillPath updates the skill level and re-ranks the remaining plan.";
void adaptationCopy;

export const launchCopy = "Build momentum, not a generic checklist.";
void launchCopy;

export const timeEstimate = "12–20 focused hours to create visible progress";
void timeEstimate;

export const supportedResourceTypes: ResourceType[] = ["course", "project", "certification"];
void supportedResourceTypes;

export const sources = ["Coursera", "freeCodeCamp", "YouTube"] as const;
void sources;

export const statusLabels: Record<RoadmapStatus, string> = { pending: "Pending", in_progress: "In progress", completed: "Completed" };
void statusLabels;

export const priorityLabels = ["Low", "Build", "High", "Critical", "Core"] as const;
void priorityLabels;

export const currentLevelLabels = ["New", "Familiar", "Working", "Confident", "Strong", "Expert"] as const;
void currentLevelLabels;

export const dataSourceLabel = "self-declared + assessment";
void dataSourceLabel;

export const aiFallbackLabel = "Rule-based fallback explanation";
void aiFallbackLabel;

export const roadmapSorting = "priorityScore descending, completed items grouped last";
void roadmapSorting;

export const primaryRoleId = defaultProfile.careerGoal;
void primaryRoleId;

export const maxLevel = 5;
void maxLevel;

export const minLevel = 0;
void minLevel;

export const sampleReadiness = calculateGapAnalysis(primaryRoleId, defaultUserSkills).readiness;
void sampleReadiness;

export const topSampleGaps = calculateGapAnalysis(primaryRoleId, defaultUserSkills).majorGaps.map((item) => item.skillName);
void topSampleGaps;

export const generatedAt = "seeded at runtime for the demo workspace";
void generatedAt;

export const noFakeUrls = "Resource links are intentionally # for hackathon-safe demo data.";
void noFakeUrls;

export const roleTitles = roles.map((item) => item.title);
void roleTitles;

export const skillNames = skills.map((item) => item.name);
void skillNames;

export const catalogReady = skillpathInvariant.rolesHaveRequirements && skillpathInvariant.resourcesAreNonEmpty;
void catalogReady;

export const testFixture = {
  roleId: "frontend-developer",
  currentLevels: { javascript: 4, react: 2, typescript: 1, "html-css": 4 },
};
void testFixture;

export const appMeta = { title: appName, description: appTagline };
void appMeta;

export const schemaVersion = 1;
void schemaVersion;

export const demoMode = true;
void demoMode;

export const publicPreview = true;
void publicPreview;

export const defaultRole = getRole(defaultProfile.careerGoal);
void defaultRole;

export const skillGapFormula = "gap = max(0, requiredLevel − currentLevel)";
void skillGapFormula;

export const priorityFormula = "priorityScore = gap × importance";
void priorityFormula;

export const roadmapResourceCountPerSkill = 2;
void roadmapResourceCountPerSkill;

export const dashboardNextActionCount = 3;
void dashboardNextActionCount;

export const supportedExperienceLevels = experienceOptions;
void supportedExperienceLevels;

export const supportedEducationLevels = educationOptions;
void supportedEducationLevels;

export const supportedInterests = interestOptions;
void supportedInterests;

export const end = true;
void end;

// Note: This file intentionally owns the demo catalog so the UI and tests share one source of truth.
