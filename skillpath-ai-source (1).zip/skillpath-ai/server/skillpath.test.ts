import { describe, expect, it } from "vitest";
import { buildRoadmap, calculateGapAnalysis, defaultUserSkills, getRole, type RoadmapItem, type UserSkill } from "@shared/skillpath";

describe("SkillPath recommendation engine", () => {
  it("computes exact gap values and readiness for a fixed fixture", () => {
    const fixture: UserSkill[] = [
      { skillId: "javascript", currentLevel: 4, source: "assessment" },
      { skillId: "react", currentLevel: 2, source: "self-declared" },
      { skillId: "typescript", currentLevel: 1, source: "self-declared" },
      { skillId: "html-css", currentLevel: 4, source: "assessment" },
    ];
    const analysis = calculateGapAnalysis("frontend-developer", fixture);
    const react = analysis.items.find((item) => item.skillId === "react");
    const typescript = analysis.items.find((item) => item.skillId === "typescript");
    const performance = analysis.items.find((item) => item.skillId === "performance");
    expect(react?.gap).toBe(2);
    expect(react?.priorityScore).toBe(10);
    expect(typescript?.gap).toBe(2);
    expect(performance?.gap).toBe(3);
    expect(analysis.readiness).toBe(34.4);
  });

  it("ranks the largest weighted gaps first", () => {
    const roadmap = buildRoadmap("frontend-developer", defaultUserSkills);
    expect(roadmap[0]?.skillId).toBe("performance");
    expect(roadmap[0]?.priorityScore).toBeGreaterThanOrEqual(roadmap[2]?.priorityScore ?? 0);
  });

  it("changes the remaining roadmap after an item is completed", () => {
    const role = getRole("frontend-developer");
    const before = buildRoadmap(role.id, defaultUserSkills);
    const completed = before[0] as RoadmapItem;
    const upgraded = defaultUserSkills.map((item) => ({ ...item }));
    const skill = upgraded.find((item) => item.skillId === completed.skillId);
    if (skill) skill.currentLevel = Math.min(5, skill.currentLevel + 1);
    const after = buildRoadmap(role.id, upgraded, [completed.skillId]);
    expect(after[0]?.skillId).not.toBe(completed.skillId);
    expect(after.filter((item) => item.status === "completed").every((item) => item.skillId === completed.skillId)).toBe(true);
  });
});
