import { int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  education: varchar("education", { length: 120 }),
  experienceLevel: varchar("experienceLevel", { length: 80 }),
  interests: json("interests"),
  careerGoal: varchar("careerGoal", { length: 120 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const skills = mysqlTable("skills", {
  id: varchar("id", { length: 80 }).primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  description: text("description").notNull(),
});

export const roles = mysqlTable("roles", {
  id: varchar("id", { length: 80 }).primaryKey(),
  title: varchar("title", { length: 120 }).notNull(),
  requiredSkills: json("requiredSkills").notNull(),
});

export const userSkills = mysqlTable("userSkills", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  skillId: varchar("skillId", { length: 80 }).notNull(),
  currentLevel: int("currentLevel").notNull(),
  source: mysqlEnum("source", ["self-declared", "assessment"]).notNull(),
});

export const learningResources = mysqlTable("learningResources", {
  id: varchar("id", { length: 120 }).primaryKey(),
  skillId: varchar("skillId", { length: 80 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  type: mysqlEnum("type", ["course", "project", "certification"]).notNull(),
  provider: varchar("provider", { length: 80 }).notNull(),
  estimatedHours: int("estimatedHours").notNull(),
  url: varchar("url", { length: 500 }).notNull(),
});

export const roadmapItems = mysqlTable("roadmapItems", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  resourceId: varchar("resourceId", { length: 120 }).notNull(),
  skillId: varchar("skillId", { length: 80 }).notNull(),
  status: mysqlEnum("status", ["pending", "in_progress", "completed"]).default("pending").notNull(),
  priority: int("priority").notNull(),
  reasonText: text("reasonText").notNull(),
  addedAt: timestamp("addedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
