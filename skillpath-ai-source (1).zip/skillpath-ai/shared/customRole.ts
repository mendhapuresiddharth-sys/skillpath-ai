import { resources, roles, skills, type RequiredSkill, type Role, type SkillCategory } from "@shared/skillpath";

const stopWords = new Set(["and", "or", "the", "for", "with", "of", "a", "an", "in", "to", "lead", "senior", "junior", "associate", "principal", "manager", "engineer", "developer", "designer", "analyst", "specialist"]);
const keywordSkillMap: Record<string, string[]> = {
  web: ["javascript", "html-css", "react", "typescript", "accessibility", "performance"],
  frontend: ["javascript", "react", "typescript", "html-css", "accessibility", "testing", "performance"],
  backend: ["node", "express", "sql", "api-design", "testing", "docker", "system-design"],
  fullstack: ["javascript", "react", "node", "sql", "api-design", "testing", "docker"],
  data: ["sql", "python", "statistics", "pandas", "data-visualization", "communication"],
  analytics: ["sql", "statistics", "excel", "data-visualization", "python", "data-storytelling"],
  product: ["product-strategy", "user-research", "roadmapping", "communication", "stakeholder-management", "agile"],
  design: ["ux-ui", "user-research", "accessibility", "design-systems", "prototyping", "presentation"],
  cloud: ["aws", "cloud-architecture", "terraform", "docker", "networking", "security-fundamentals"],
  devops: ["linux", "docker", "kubernetes", "ci-cd", "monitoring", "terraform"],
  security: ["security-fundamentals", "networking", "threat-modeling", "incident-response", "cloud-security", "scripting"],
  cyber: ["security-fundamentals", "networking", "threat-modeling", "siem", "incident-response", "cryptography"],
  machine: ["python", "machine-learning", "statistics", "linear-algebra", "numpy", "tensorflow"],
  ai: ["python", "machine-learning", "statistics", "linear-algebra", "tensorflow", "experiment-design"],
  mobile: ["react-native", "typescript", "javascript", "api-design", "testing", "performance", "app-store"],
  mobileapp: ["react-native", "typescript", "javascript", "api-design", "testing", "performance", "app-store"],
};
const fallbackSkillIds = ["communication", "problem-solving", "git", "testing", "system-design", "presentation", "sql", "api-design"];

const slugify = (value: string) => value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 48) || "custom-role";
const normalizeTokens = (value: string) => value.toLowerCase().split(/[^a-z0-9]+/).filter((token) => token.length > 2 && !stopWords.has(token));
const categoryForToken = (token: string): SkillCategory => token.includes("data") || token.includes("science") ? "Data" : token.includes("cloud") || token.includes("platform") || token.includes("infra") ? "Cloud & DevOps" : token.includes("design") || token.includes("product") || token.includes("research") ? "Professional" : "Programming";

export function ensureSkill(skillId: string, title: string): string {
  if (skills.some((skill) => skill.id === skillId)) return skillId;
  const skillName = title.replace(/\b\w/g, (letter) => letter.toUpperCase());
  skills.push({ id: skillId, name: skillName, category: categoryForToken(skillId), description: `Build practical capability for ${skillName.toLowerCase()} work.` });
  ["course", "project", "certification"].forEach((type, index) => resources.push({ id: `resource-${skillId}-${index + 1}`, skillId, title: `${type === "project" ? "Ship a portfolio project with" : type === "certification" ? "Validate your" : "Build a practical"} ${skillName}`, type: type as "course" | "project" | "certification", provider: index === 0 ? "Coursera" : index === 1 ? "freeCodeCamp" : "YouTube", estimatedHours: 6 + index * 4, url: "#" }));
  return skillId;
}

export function matchOrCreateSkill(name: string): string {
  const normalized = name.trim().toLowerCase();
  const existing = skills.find((skill) => skill.id === normalized || skill.name.toLowerCase() === normalized);
  return existing?.id ?? ensureSkill(`custom-${slugify(name)}`, name);
}

export function heuristicRequiredSkills(title: string): RequiredSkill[] {
  const tokens = normalizeTokens(title);
  const selected: string[] = [];
  tokens.forEach((token) => (keywordSkillMap[token] ?? []).forEach((skillId) => { if (!selected.includes(skillId)) selected.push(skillId); }));
  tokens.forEach((token) => {
    if (skills.some((skill) => skill.id === token) && !selected.includes(token)) selected.push(token);
    if (!skills.some((skill) => skill.id === token) && !stopWords.has(token) && token.length > 4 && selected.length < 10) selected.push(ensureSkill(`custom-${slugify(token)}`, token));
  });
  fallbackSkillIds.forEach((skillId) => { if (selected.length < 8 && !selected.includes(skillId)) selected.push(skillId); });
  return selected.slice(0, 12).map((skillId, index) => ({ skillId, importance: index < 3 ? 5 : index < 7 ? 4 : 3, minLevel: index < 3 ? 4 : index < 7 ? 3 : 2 }));
}

export function createHeuristicRole(title: string): Role {
  const cleanTitle = title.trim().replace(/\s+/g, " ");
  const id = `custom-${slugify(cleanTitle)}`;
  const existing = roles.find((role) => role.id === id);
  if (existing) return existing;
  const newRole: Role = { id, title: cleanTitle, shortDescription: `A personalized path for becoming a strong ${cleanTitle}.`, accent: "#0F766E", requiredSkills: heuristicRequiredSkills(cleanTitle) };
  roles.push(newRole);
  return newRole;
}

export function updateRoleRequirements(roleId: string, requiredSkills: RequiredSkill[]): Role {
  const role = roles.find((candidate) => candidate.id === roleId);
  if (!role) throw new Error("Role not found");
  role.requiredSkills = requiredSkills.map((requirement) => ({ ...requirement, importance: Math.max(1, Math.min(5, Math.round(requirement.importance))), minLevel: Math.max(1, Math.min(5, Math.round(requirement.minLevel))) }));
  return role;
}
