import "dotenv/config";
import { eq } from "drizzle-orm";
import { demoUser, defaultProfile, defaultUserSkills, buildRoadmap, resources, roles, skills } from "@shared/skillpath";
import { learningResources, roadmapItems, roles as roleTable, skills as skillTable, userSkills, users } from "../drizzle/schema";
import { getDb } from "./db";

async function seed() {
  const db = await getDb();
  if (!db) {
    console.log(`[seed] DATABASE_URL is not configured; shared demo catalog remains available in fallback mode.`);
    console.log(`[seed] ${skills.length} skills, ${roles.length} roles, ${resources.length} learning resources.`);
    return;
  }

  await db.insert(skillTable).values(skills).onDuplicateKeyUpdate({ set: { name: skills[0]!.name, category: skills[0]!.category, description: skills[0]!.description } });
  await db.insert(roleTable).values(roles.map((role) => ({ id: role.id, title: role.title, requiredSkills: role.requiredSkills }))).onDuplicateKeyUpdate({ set: { title: roles[0]!.title, requiredSkills: roles[0]!.requiredSkills } });
  await db.insert(learningResources).values(resources).onDuplicateKeyUpdate({ set: { title: resources[0]!.title, provider: resources[0]!.provider, estimatedHours: resources[0]!.estimatedHours, url: resources[0]!.url } });

  await db.insert(users).values({
    openId: "demo-skillpath-user",
    name: defaultProfile.name,
    email: demoUser.email,
    loginMethod: "demo",
    education: defaultProfile.education,
    experienceLevel: defaultProfile.experienceLevel,
    interests: defaultProfile.interests,
    careerGoal: defaultProfile.careerGoal,
  }).onDuplicateKeyUpdate({ set: { name: defaultProfile.name, education: defaultProfile.education, experienceLevel: defaultProfile.experienceLevel, interests: defaultProfile.interests, careerGoal: defaultProfile.careerGoal } });

  const [demo] = await db.select({ id: users.id }).from(users).where(eq(users.email, demoUser.email)).limit(1);
  if (demo) {
    await db.delete(userSkills).where(eq(userSkills.userId, demo.id));
    await db.insert(userSkills).values(defaultUserSkills.map((skill) => ({ userId: demo.id, skillId: skill.skillId, currentLevel: skill.currentLevel, source: skill.source })));
    await db.delete(roadmapItems).where(eq(roadmapItems.userId, demo.id));
    const roadmap = buildRoadmap(defaultProfile.careerGoal, defaultUserSkills);
    await db.insert(roadmapItems).values(roadmap.map((item) => ({ userId: demo.id, resourceId: item.resourceId, skillId: item.skillId, status: item.status, priority: item.priority, reasonText: item.reasonText })));
  }
  console.log(`[seed] Seeded ${skills.length} skills, ${roles.length} roles, ${resources.length} resources and the demo user ${demoUser.email}.`);
}

seed().catch((error) => {
  console.error("[seed] Failed:", error);
  process.exitCode = 1;
});
