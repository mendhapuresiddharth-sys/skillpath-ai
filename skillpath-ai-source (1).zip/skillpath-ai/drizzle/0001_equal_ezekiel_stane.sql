CREATE TABLE `learningResources` (
	`id` varchar(120) NOT NULL,
	`skillId` varchar(80) NOT NULL,
	`title` varchar(180) NOT NULL,
	`type` enum('course','project','certification') NOT NULL,
	`provider` varchar(80) NOT NULL,
	`estimatedHours` int NOT NULL,
	`url` varchar(500) NOT NULL,
	CONSTRAINT `learningResources_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `roadmapItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`resourceId` varchar(120) NOT NULL,
	`skillId` varchar(80) NOT NULL,
	`status` enum('pending','in_progress','completed') NOT NULL DEFAULT 'pending',
	`priority` int NOT NULL,
	`reasonText` text NOT NULL,
	`addedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `roadmapItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `roles` (
	`id` varchar(80) NOT NULL,
	`title` varchar(120) NOT NULL,
	`requiredSkills` json NOT NULL,
	CONSTRAINT `roles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `skills` (
	`id` varchar(80) NOT NULL,
	`name` varchar(120) NOT NULL,
	`category` varchar(80) NOT NULL,
	`description` text NOT NULL,
	CONSTRAINT `skills_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userSkills` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`skillId` varchar(80) NOT NULL,
	`currentLevel` int NOT NULL,
	`source` enum('self-declared','assessment') NOT NULL,
	CONSTRAINT `userSkills_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `education` varchar(120);--> statement-breakpoint
ALTER TABLE `users` ADD `experienceLevel` varchar(80);--> statement-breakpoint
ALTER TABLE `users` ADD `interests` json;--> statement-breakpoint
ALTER TABLE `users` ADD `careerGoal` varchar(120);