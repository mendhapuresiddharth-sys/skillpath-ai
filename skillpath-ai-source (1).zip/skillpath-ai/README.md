# SkillPath AI

SkillPath AI is a personalized career and skill navigator built for a fast, judgeable hackathon demo. It turns a learner profile into a target-role skill gap, an explainable action plan, and an adaptive roadmap that visibly changes as work is completed.

## What is included

The project is a WebDev full-stack app using React, Vite, Tailwind CSS, Recharts, Express, tRPC, Drizzle, MySQL/TiDB, and Manus OAuth scaffolding. The product experience is intentionally demo-ready: the shared catalog includes more than 60 skills across five categories, ten target roles, and three learning resources per catalog skill. The default workspace opens with a profiled demo persona, Maya Chen, targeting Frontend Developer.

The recommendation engine is deterministic by design:

- `gap = max(0, requiredLevel - currentLevel)`
- `priorityScore = gap × importance`
- readiness is `100 × sum(min(currentLevel, requiredLevel)) / sum(requiredLevel)`
- completing an item raises that skill by one level and rebuilds the remaining roadmap
- editing a role requirement through `roles.update` (the typed `/api/trpc` equivalent of `PATCH /api/roles/:id`) rebuilds the affected user's roadmap on the next load

When no LLM key is configured, the UI labels the explainability layer as **Rule-based fallback** and uses a guaranteed deterministic explanation. The architecture leaves room for an AI-generated wording layer without making the demo dependent on a paid or unavailable external key.

## Run locally

```bash
pnpm install
pnpm db:push
pnpm seed
pnpm dev
```

Open the preview URL printed by the dev server. The current demo workspace is available without a separate signup step; production identity can use the scaffolded Manus OAuth flow.

Useful commands:

```bash
pnpm check   # TypeScript validation
pnpm test    # Vitest unit and API-adjacent logic tests
pnpm build   # Production client + server build
```

The `.env.example` should contain the platform-provided database, OAuth, and session variables. Do not commit real credentials.

## Architecture

```text
React + Tailwind + Recharts
        │
        │ typed tRPC procedures under /api/trpc
        ▼
Express / server/routers.ts
        │
        ├── shared/skillpath.ts  ← seed catalog + gap / ranking logic
        ├── drizzle/schema.ts     ← users, skills, roles, userSkills,
        │                            learningResources, roadmapItems
        └── MySQL/TiDB via Drizzle
```

The first demo pass keeps the active workspace state in the server process so judges can exercise the entire flow instantly, even if a database is not configured. The relational schema and `pnpm seed` script are included for persistence-ready handoff.

## Demo flow

1. Open the landing page and choose **Open workspace**.
2. Review the Overview dashboard, including the readiness ring, skill radar, weighted top gaps, and next actions.
3. Open **Explore roles**, select a different role, or use **Define your own target role** to build a custom path from a title.
4. Open **Skill gap** to inspect current vs. required levels and the explanation behind each major recommendation.
5. Open **My roadmap**. Move a card to **In progress** or choose **Mark complete**. Completing a step updates the skill level, changes readiness, and re-ranks the remaining cards. Use **Edit requirements** to change the role itself and visibly trigger a second kind of roadmap refresh.
6. Use **Progress** for the trend and milestone view, or **Profile** to rerun the onboarding wizard and adjust the starting assumptions.

## Evaluation mapping

| Hackathon metric | SkillPath AI feature | Evidence in the app |
| --- | --- | --- |
| Skill-Gap Accuracy | Explicit gap and readiness formulas | Skill gap page and deterministic tests |
| Personalization Quality | Profile wizard + role-specific levels | Profile, interests, experience, and target-role inputs |
| Roadmap Quality | Weighted gap × importance ranking | Roadmap board with 1–2 resources per priority skill |
| Adaptability | Both progress-based re-ranking and requirements-change re-ranking | Completion updates skill levels; `PATCH /api/roles/:id` / `roles.update` edits role requirements and refreshes the affected roadmap |
| Recommendation Relevance | Resources attach to the missing skill | Course, project, and certification cards with estimated hours |
| Explainability | Reason text includes gap and role importance | Explanation cards and rule-based fallback label |

## Tests

The backend test suite covers authentication cookie behavior inherited from the template, exact gap/readiness calculations, weighted ordering, and roadmap re-ranking after completion. The core UI uses a stateful profile wizard and roadmap board wired to live tRPC mutations, making the primary demo behaviors directly testable in-browser.

## Branding

The SkillPath AI logo is rendered as an inline SVG using the required blue-to-teal upward path motif. The same motif is used in the landing header, workspace sidebar, and product metadata.
